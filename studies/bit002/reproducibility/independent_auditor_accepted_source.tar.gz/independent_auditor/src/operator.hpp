#pragma once
#include "base.hpp"
namespace brc {
enum Purpose {INITIAL_GENOTYPE,CHECKPOINT_TIME,TARGET_INNOVATION,TARGET_COPY,FRESH_MASK,SCOUT_MASK,LOCAL_BIT,DONOR_KEY,SURVIVAL_UNIFORM,POLICY_MUTATION,FOCAL_PARENT,PURPOSES};
inline const std::array<std::string,PURPOSES>& purposes(){static const std::array<std::string,PURPOSES> p{{"INITIAL_GENOTYPE","CHECKPOINT_TIME","TARGET_INNOVATION","TARGET_COPY","FRESH_MASK","SCOUT_MASK","LOCAL_BIT","DONOR_KEY","SURVIVAL_UNIFORM","POLICY_MUTATION","FOCAL_PARENT"}};return p;}
using Words=std::array<uint32_t,4>;
using Key=std::array<uint32_t,2>;
inline Words philox(Words c,Key k) {
 for(unsigned r=0;r<10;++r){uint64_t a=uint64_t(0xd2511f53U)*c[0],b=uint64_t(0xcd9e8d57U)*c[2];c={{uint32_t(b>>32)^c[1]^k[0],uint32_t(b),uint32_t(a>>32)^c[3]^k[1],uint32_t(a)}};if(r!=9){k[0]+=0x9e3779b9U;k[1]+=0xbb67ae85U;}}return c;
}
inline Key derive(const Tier& t,Purpose p){auto d=sha(std::string(STUDY)+"|"+t.name+"|"+purposes()[p]);Bytes b(d.begin(),d.end());return {{uint32_t(get(b,0,4)),uint32_t(get(b,4,4))}};}
class RNG {
 Tier tr;std::array<Key,PURPOSES> keys;unsigned constructed_checkpoint=0;
public:
 explicit RNG(Tier t,unsigned fixture_u=0):tr(t),constructed_checkpoint(fixture_u){require(fixture_u==0||(t.code==2&&fixture_u<=256),"fixture-only checkpoint context");for(unsigned p=0;p<PURPOSES;++p)keys[p]=derive(t,Purpose(p));}
 const Tier& contract() const{return tr;}
 unsigned checkpoint_update(uint32_t b)const{return constructed_checkpoint?constructed_checkpoint:tr.checkpoint(word(CHECKPOINT_TIME,b,0,0));}
 Words at(Purpose p,uint32_t b,uint32_t u,uint32_t e,uint32_t s=0)const {
  require(unsigned(p)<PURPOSES&&b<tr.n,"random coordinate");
  if(p==INITIAL_GENOTYPE)require(u==0&&e<32&&s==0,"initial coordinate");
  else if(p==CHECKPOINT_TIME)require(u==0&&e==0&&s==0,"checkpoint coordinate");
  else {require(u>=1&&u<=256,"update coordinate");
   if(p==TARGET_INNOVATION||p==TARGET_COPY)require(e==0&&s==0,"target coordinate");
   else if(p==LOCAL_BIT)require(e<32&&s<32,"local coordinate");
   else if(p==DONOR_KEY)require(e<96&&s==0,"donor coordinate");
   else if(p==SURVIVAL_UNIFORM)require(e<32&&s<256,"survival coordinate");
   else {require(e<32&&s==0,"slot coordinate");if(p==FOCAL_PARENT)require(u==checkpoint_update(b),"focal checkpoint coordinate");}
  }
  return philox({{b,u,e,s}},keys[p]);
 }
 uint32_t word(Purpose p,uint32_t b,uint32_t u,uint32_t e,uint32_t s=0)const{return at(p,b,u,e,s)[0];}
 uint64_t wide(Purpose p,uint32_t b,uint32_t u,uint32_t e,uint32_t s=0)const{auto w=at(p,b,u,e,s);return uint64_t(w[0])|(uint64_t(w[1])<<32);}
};
struct DrawFault:Error {explicit DrawFault(const std::string& s):Error(s){}};
struct Tape {
 std::array<uint32_t,32> fresh{},scout{},local{};
 std::array<uint64_t,96> donor{};
 std::array<uint64_t,32> focal{};
 std::array<std::vector<uint64_t>,32> survival;
 uint32_t flip=0;
 std::function<uint64_t(unsigned,unsigned)> generated;
 uint64_t x(unsigned d,unsigned r)const {
  if(r>=256)throw DrawFault("RETRY_CAP");require(d<32,"draw coordinate");
  if(generated)return generated(d,r);
  if(r>=survival[d].size())throw DrawFault("DRAW_EXHAUSTED");return survival[d][r];
 }
};
inline Tape tape(const RNG& rng,uint32_t b,unsigned u,bool with_focal=true) {
 Tape t;
 for(unsigned i=0;i<32;++i){t.fresh[i]=rng.word(FRESH_MASK,b,u,i);t.scout[i]=rng.word(SCOUT_MASK,b,u,i);if(with_focal)t.focal[i]=rng.wide(FOCAL_PARENT,b,u,i);if((rng.word(POLICY_MUTATION,b,u,i)&31)==0)t.flip|=uint32_t(1)<<i;for(unsigned bit=0;bit<32;++bit)if((rng.word(LOCAL_BIT,b,u,i,bit)&31)==0)t.local[i]|=uint32_t(1)<<bit;}
 for(unsigned i=0;i<96;++i)t.donor[i]=rng.wide(DONOR_KEY,b,u,i);
 t.generated=[&rng,b,u](unsigned d,unsigned r){return rng.wide(SURVIVAL_UNIFORM,b,u,d,r);};return t;
}
struct State {std::array<uint32_t,32> x{},cache{};uint32_t policy=0,valid=0;};
inline Bytes encode(const State& s){Bytes b(264,0);for(unsigned i=0;i<32;++i){put(b,4*i,s.x[i],4);put(b,128+4*i,s.cache[i],4);}put(b,256,s.policy,4);put(b,260,s.valid,4);return b;}
inline State prestate(const Bytes& r){State s;for(unsigned i=0;i<32;++i){s.x[i]=uint32_t(get(r,104+4*i,4));s.cache[i]=uint32_t(get(r,232+4*i,4));}s.policy=uint32_t(get(r,52,4));s.valid=uint32_t(get(r,56,4));return s;}
inline State initial(const RNG& rng,uint32_t b){State s;s.policy=(b&1)?0xffffffffU:0;for(unsigned i=0;i<32;++i)s.x[i]=rng.word(INITIAL_GENOTYPE,b,0,i);return s;}
struct Focal {uint32_t E=0;unsigned e=0,slot=255;uint64_t key=UINT64_MAX;};
inline Focal focal(const State& s,const std::array<uint64_t,32>& keys){Focal f;f.E=s.policy&s.valid;f.e=pop(f.E);for(unsigned i=0;i<32;++i)if((f.E>>i)&1){if(f.slot==255||keys[i]<f.key){f.slot=i;f.key=keys[i];}}return f;}
// The first acceptable multiply-high result; exhaustion is not an extra draw.
inline std::pair<unsigned,uint64_t> lemire(uint64_t W,const std::function<uint64_t(unsigned)>& x) {
 require(W>=1&&W<=(uint64_t(1)<<39),"weight range");uint64_t threshold=(uint64_t(0)-W)%W;
 for(unsigned r=0;r<256;++r){uint64_t a=x(r);__uint128_t m=__uint128_t(a)*W;if(uint64_t(m)>=threshold)return {r,uint64_t(m>>64)};}
 throw DrawFault("RETRY_CAP");
}
struct Turn {State state;Bytes arm;unsigned retries=0;};
inline Turn turnover(const State& s,uint32_t target,uint32_t Q,const Tape& t,const Focal& f,unsigned arm,unsigned rt) {
 std::array<uint32_t,128> g{};std::array<unsigned,128> mismatch{};std::array<uint64_t,128> w{};
 unsigned mismatch_sum=0;
 for(unsigned i=0;i<32;++i){g[i]=s.x[i];g[32+i]=(((s.policy&s.valid&~Q)>>i)&1)?s.cache[i]:(s.x[i]^t.fresh[i]);g[64+i]=s.x[i]^t.scout[i];
  unsigned best=0;for(unsigned a=0;a<3;++a){mismatch[32*a+i]=pop(g[32*a+i]^target);if(a&& (mismatch[32*a+i]<mismatch[32*best+i]||(mismatch[32*a+i]==mismatch[32*best+i]&&t.donor[3*i+a]<t.donor[3*i+best])))best=a;}
  g[96+i]=g[32*best+i]^t.local[i];mismatch[96+i]=pop(g[96+i]^target);
 }
 for(unsigned j=0;j<128;++j){w[j]=uint64_t(1)<<(32-mismatch[j]);mismatch_sum+=mismatch[j];}
 Turn out;out.arm.assign(280,0);auto& a=out.arm;put(a,0,arm,1);put(a,1,arm/3,1);put(a,2,arm%3,1);put(a,3,arm==(rt?0U:3U),1);put(a,4,Q,4);put(a,8,128,2);put(a,20,mismatch_sum,4);
 unsigned DE=0,df=0,A=0;
 for(unsigned d=0;d<32;++d){uint64_t W=0;for(unsigned j=0;j<128;++j)W+=w[j];auto z=lemire(W,[&t,d](unsigned r){return t.x(d,r);});uint64_t cumulative=0;unsigned chosen=128;
  for(unsigned j=0;j<128;++j){cumulative+=w[j];if(cumulative>z.second){chosen=j;break;}}
  require(chosen<128&&w[chosen]!=0,"selection");w[chosen]=0;unsigned p=chosen%32;unsigned pol=((s.policy>>p)^(t.flip>>d))&1;
  out.state.x[d]=g[chosen];if(pol){out.state.policy|=uint32_t(1)<<d;out.state.valid|=uint32_t(1)<<d;out.state.cache[d]=s.x[p];}
  DE+=(f.E>>p)&1;df+=(p==f.slot);A+=32-mismatch[chosen];out.retries+=z.first;
  size_t off=24+8*d;put(a,off,chosen,1);put(a,off+1,mismatch[chosen],1);put(a,off+2,pol,1);put(a,off+3,z.first,1);put(a,off+4,g[chosen],4);
 }
 put(a,10,out.retries,2);put(a,12,DE,1);put(a,13,df,1);put(a,14,A,2);put(a,16,out.state.policy,4);return out;
}
using Six=std::array<int64_t,6>;
inline Six numerators(const std::array<Bytes,6>& a){return {{int64_t(get(a[0],12,1))-int64_t(get(a[1],12,1)),int64_t(get(a[3],12,1))-int64_t(get(a[4],12,1)),int64_t(get(a[0],14,2))-int64_t(get(a[1],14,2)),int64_t(get(a[3],14,2))-int64_t(get(a[4],14,2)),int64_t(get(a[0],13,1))-int64_t(get(a[2],13,1)),int64_t(get(a[3],13,1))-int64_t(get(a[5],13,1))}};}
inline Six recordnums(const Bytes& r){auto signedv=[&r](size_t o,unsigned n){int64_t v=int64_t(get(r,o,n));if(v&(int64_t(1)<<(8*n-1)))v-=int64_t(1)<<(8*n);return v;};return {{signedv(2040,1),signedv(2041,1),signedv(2042,2),signedv(2044,2),signedv(2046,1),signedv(2047,1)}};}
inline void setnums(Bytes& r,const Six& n){put(r,2040,uint64_t(n[0]),1);put(r,2041,uint64_t(n[1]),1);put(r,2042,uint64_t(n[2]),2);put(r,2044,uint64_t(n[3]),2);put(r,2046,uint64_t(n[4]),1);put(r,2047,uint64_t(n[5]),1);}
inline std::array<Bytes,6> recordarms(const Bytes& r){std::array<Bytes,6> a;for(unsigned j=0;j<6;++j)a[j]=slice(r,360+280*j,280);return a;}
struct Checkpoint {Focal f;std::array<Bytes,6> arms;Six nums;};
inline Checkpoint checkpoint(const State& s,uint32_t rec,uint32_t inn,unsigned rt,const Tape& t){Checkpoint c;c.f=focal(s,t.focal);for(unsigned a=0;a<6;++a){uint32_t Q=a%3==0?0:a%3==1?c.f.E:c.f.slot==255?0:uint32_t(1)<<c.f.slot;c.arms[a]=turnover(s,a<3?rec:inn,Q,t,c.f,a,rt).arm;}c.nums=numerators(c.arms);return c;}
inline Digest digest0(uint32_t b,const State& s){Bytes msg=bytes("BRC2-HIST-V2");append(msg,b,4);append(msg,encode(s));return sha(msg);}
inline Digest digestnext(const Digest& prior,unsigned u,uint32_t T,unsigned retries,const State& s){Bytes msg;append(msg,prior);append(msg,u,2);append(msg,T,4);append(msg,retries,4);append(msg,encode(s));return sha(msg);}
struct History {State s;std::array<uint32_t,257> targets{};uint32_t retries=0;std::vector<Digest> trace;};
inline History history(const RNG& rng,uint32_t b,unsigned t){require(t>=193&&t<=256,"history checkpoint");History h;h.s=initial(rng,b);h.trace.push_back(digest0(b,h.s));for(unsigned u=1;u<t;++u){uint32_t I=rng.word(TARGET_INNOVATION,b,u,0);unsigned R=rng.word(TARGET_COPY,b,u,0)&1;h.targets[u]=u>=3&&R?h.targets[u-2]:I;auto w=tape(rng,b,u,false);Focal f;auto step=turnover(h.s,h.targets[u],0,w,f,0,1);h.s=step.state;h.retries+=step.retries;h.trace.push_back(digestnext(h.trace.back(),u,h.targets[u],step.retries,h.s));}return h;}
// Only for the later FORGE_CACHE test: rewrite an existing block, never a cohort producer.
inline void rearm(Bytes& r,const RNG& rng){auto s=prestate(r);unsigned b=unsigned(get(r,8,4)),u=unsigned(get(r,14,2));auto t=tape(rng,b,u);auto c=checkpoint(s,uint32_t(get(r,20,4)),uint32_t(get(r,28,4)),unsigned(get(r,13,1)),t);for(unsigned a=0;a<6;++a)std::copy(c.arms[a].begin(),c.arms[a].end(),r.begin()+360+280*a);setnums(r,c.nums);auto h=sha(slice(r,0,2056));std::copy(h.begin(),h.end(),r.begin()+2056);}
} // namespace brc
