#include "audit.hpp"
int main(int argc,char** argv){using namespace brc;bool committing=false;try{
 std::map<std::string,std::string> args;bool timing=false;
 for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--timing-only"){require(!timing,"duplicate flag");timing=true;}else{require(a=="--tier"||a=="--data"||a=="--out","argument");require(!args.count(a)&&i+1<argc,"argument value");args[a]=argv[++i];}}
 require(args.size()==3&&args.count("--tier")&&args.count("--data")&&args.count("--out"),"arguments");auto t=tier(args["--tier"]);fs::path out=args["--out"],dir=args["--data"];require(!out.empty()&&!out.filename().empty()&&out.filename()!="."&&out.filename()!=".."&&out.filename()!="AUDIT_REPORT.txt","output path");
 auto parent=out.parent_path();if(parent.empty())parent=".";require(fs::is_directory(parent),"output parent");require(timing||(::access(parent.c_str(),W_OK)==0&&!fs::is_directory(out)),"output environment");
 // Results and audit reports cannot enter the producer's exact data inventory.
 auto dp=fs::weakly_canonical(dir),op=fs::weakly_canonical(parent);auto rel=op.lexically_relative(dp);require(op!=dp&&(rel.empty()||*rel.begin()==".."),"output inside data");
 auto begin=Clock::now();auto r=audit(t,dir);hash_and_discard(r.results);hash_and_discard(r.report);bool pass=!r.checks.bad();
 if(!timing){committing=true;writefile(parent/"AUDIT_REPORT.txt",r.report,0400);writefile(out,r.results,0400);committing=false;}
 std::cout<<"status="<<(pass?"VALID":"INVALID")<<" total_seconds="<<std::fixed<<std::setprecision(9)<<seconds(begin,Clock::now())<<" K_seconds="<<r.k_seconds<<'\n';return pass?0:1;
 }catch(const std::exception&){std::cerr<<(committing?"runtime_output_failure\n":"usage_or_environment_error\n");return committing?3:2;}}
