#pragma once
#include "audit.hpp"
#include <memory>
namespace brc {
struct InputFault:Error {explicit InputFault(const std::string& s):Error(s){}};
inline void syntax(bool b){if(!b)throw InputFault("INPUT_SYNTAX");}
inline void range(bool b){if(!b)throw InputFault("INPUT_RANGE");}
inline bool valid_id(const std::string& s){return !s.empty()&&s.size()<=32&&std::all_of(s.begin(),s.end(),[](char c){return (c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_';});}
struct Reader {
 std::vector<std::string> l;size_t p=0;
 explicit Reader(const Bytes& b){try{l=lines(b);}catch(const Error&){throw InputFault("INPUT_SYNTAX");}}
 std::string raw(){syntax(p<l.size());return l[p++];}
 std::string field(const std::string& k){auto v=raw();syntax(v.rfind(k+"=",0)==0);return v.substr(k.size()+1);}
 void literal(const std::string& s){syntax(raw()==s);}
 void end(){syntax(p==l.size());}
};
inline uint64_t fdec(const std::string& s,uint64_t lo,uint64_t hi){Big a;try{a=bigint(s,false);}catch(const Error&){throw InputFault("INPUT_SYNTAX");}range(a>=lo&&a<=hi);return a.convert_to<uint64_t>();}
inline int64_t fint(const std::string& s,int64_t limit){Big a;try{a=bigint(s);}catch(const Error&){throw InputFault("INPUT_SYNTAX");}range(a>=-limit&&a<=limit);return a.convert_to<int64_t>();}
inline uint64_t fhex(const std::string& s,unsigned width){syntax(ishex(s,width));uint64_t v=0;for(char c:s)v=(v<<4)|unsigned(c<='9'?c-'0':c-'a'+10);return v;}
inline Rat ffrac(const std::string& s){try{return fraction(s);}catch(const Error&){throw InputFault("INPUT_SYNTAX");}}
inline std::vector<uint64_t> hexlist(const std::string& s,unsigned width,size_t lo,size_t hi){auto l=split(s,',');syntax(l.size()>=lo&&l.size()<=hi);std::vector<uint64_t> v;for(auto& a:l)v.push_back(fhex(a,width));return v;}
inline Six sixints(const std::string& s){auto l=split(s,',');syntax(l.size()==6);Six a{};for(unsigned j=0;j<6;++j)a[j]=fint(l[j],static_bound(j));return a;}
inline std::string sixtext(const Six& n){std::vector<std::string> v;for(auto a:n)v.push_back(std::to_string(a));return join(v);}
inline void state_input(const State& s,unsigned u){range(cachezeros(s));range((s.valid&~s.policy)==0);if(u==1)range(s.valid==0);}
inline void take32(Reader& r,const std::string& k,std::array<uint32_t,32>& a){auto l=hexlist(r.field(k),8,32,32);for(unsigned i=0;i<32;++i)a[i]=uint32_t(l[i]);}
inline Tape injected(Reader& r,const std::string& prefix){Tape t;take32(r,prefix+"fresh",t.fresh);take32(r,prefix+"scout",t.scout);take32(r,prefix+"local",t.local);auto d=hexlist(r.field(prefix+"donor"),16,96,96);std::copy(d.begin(),d.end(),t.donor.begin());for(unsigned s=0;s<32;++s){std::string dd=(s<10?"0":"")+std::to_string(s);t.survival[s]=hexlist(r.field(prefix+"survival_"+dd),16,1,256);}t.flip=uint32_t(fhex(r.field(prefix+"policy_flip"),8));auto k=hexlist(r.field(prefix+"focal"),16,32,32);std::copy(k.begin(),k.end(),t.focal.begin());return t;}
struct HistoryInput {uint32_t innov=0;unsigned copy=0;Tape tape;};
struct Fixture {
 std::string id,kind,draws;uint64_t W=0;std::vector<uint64_t> xs;
 State s;unsigned u=0,rt=0;uint32_t rec=0,inn=0;Tape tape;std::shared_ptr<RNG> rng;
 uint32_t block=0;std::vector<HistoryInput> steps;
 uint32_t n=0;Six constant{};std::map<uint32_t,Six> overrides;
 std::array<Interval,6> intervals;
};
inline Fixture read_fixin(const Bytes& b,const std::string& id){
 syntax(valid_id(id));Reader r(b);Fixture f;f.id=id;r.literal("BRC2-FIXIN-V1");syntax(r.field("fixture_id")==id);f.kind=r.field("kind");
 if(f.kind=="LEMIRE"){f.W=fhex(r.field("w"),16);range(f.W>=1&&f.W<=(uint64_t(1)<<39));f.xs=hexlist(r.field("x"),16,1,16);}
 else if(f.kind=="CHECKPOINT"){
  f.draws=r.field("draws");syntax(f.draws=="INJECTED"||f.draws=="PHILOX");
  if(f.draws=="PHILOX"){syntax(r.field("tier")=="fixture-r1");f.block=uint32_t(fdec(r.field("block"),0,15));}
  f.u=unsigned(fdec(r.field("u"),1,256));
  if(f.draws=="PHILOX")f.rng=std::make_shared<RNG>(tier("fixture-r1"),f.u);
  if(f.draws=="INJECTED")f.rt=unsigned(fdec(r.field("r_t"),0,1));
  else f.rt=f.rng->word(TARGET_COPY,f.block,f.u,0)&1;
  take32(r,"genotypes",f.s.x);take32(r,"caches",f.s.cache);f.s.policy=uint32_t(fhex(r.field("policy_mask"),8));f.s.valid=uint32_t(fhex(r.field("cache_valid_mask"),8));f.rec=uint32_t(fhex(r.field("t_rec"),8));f.inn=uint32_t(fhex(r.field("t_inn"),8));
  if(f.draws=="INJECTED")f.tape=injected(r,"");else f.tape=tape(*f.rng,f.block,f.u);state_input(f.s,f.u);
 }
 else if(f.kind=="HISTORY"){
  syntax(r.field("draws")=="INJECTED");f.draws="INJECTED";f.block=uint32_t(fdec(r.field("block_id"),0,15));auto start=r.field("start");syntax(start=="ALL_F"||start=="ALL_M");f.s.policy=start=="ALL_M"?0xffffffffU:0;f.u=unsigned(fdec(r.field("updates"),1,3));take32(r,"genotypes0",f.s.x);
  for(unsigned k=1;k<=f.u;++k){std::string p="u"+std::to_string(k)+".";HistoryInput h;h.innov=uint32_t(fhex(r.field(p+"innov"),8));h.copy=unsigned(fdec(r.field(p+"copy"),0,1));h.tape=injected(r,p);f.steps.push_back(std::move(h));}
 }
 else if(f.kind=="NUMVEC"){
  f.n=uint32_t(fdec(r.field("blocks"),1,42000));f.constant=sixints(r.field("constant"));auto ov=r.field("override");
  if(ov!="NONE"){auto items=split(ov,';');uint32_t prior=0;bool first=true;for(auto& item:items){auto pair=split(item,':');syntax(pair.size()==2);uint32_t k=uint32_t(fdec(pair[0],0,f.n-1));range(first||k>prior);f.overrides.emplace(k,sixints(pair[1]));prior=k;first=false;}}
 }
 else if(f.kind=="CLASSIFIER"){auto l=split(r.field("iv"),',');syntax(l.size()==12);for(unsigned j=0;j<6;++j){f.intervals[j]={ffrac(l[2*j]),ffrac(l[2*j+1])};range(f.intervals[j].lo<=f.intervals[j].hi);}}
 else throw InputFault("INPUT_SYNTAX");r.end();return f;
}
template<class A> inline std::string arrayhex(const A& a,unsigned width){std::vector<std::string> v;for(auto x:a)v.push_back(hx(uint64_t(x),width));return join(v);}
inline std::string injected_text(const Tape& t,const std::string& p){
 require(!t.generated,"injected writer requires explicit tape");std::ostringstream o;
 o<<p<<"fresh="<<arrayhex(t.fresh,8)<<'\n'<<p<<"scout="<<arrayhex(t.scout,8)<<'\n'<<p<<"local="<<arrayhex(t.local,8)<<'\n'<<p<<"donor="<<arrayhex(t.donor,16)<<'\n';
 for(unsigned d=0;d<32;++d)o<<p<<"survival_"<<(d<10?"0":"")<<d<<'='<<arrayhex(t.survival[d],16)<<'\n';
 o<<p<<"policy_flip="<<hx(t.flip,8)<<'\n'<<p<<"focal="<<arrayhex(t.focal,16)<<'\n';return o.str();
}
// A generic writer for supplied typed inputs. No fixture values are embedded.
inline std::string write_fixin(const Fixture& f){
 std::ostringstream o;o<<"BRC2-FIXIN-V1\nfixture_id="<<f.id<<"\nkind="<<f.kind<<'\n';
 if(f.kind=="LEMIRE")o<<"w="<<hx(f.W,16)<<"\nx="<<arrayhex(f.xs,16)<<'\n';
 else if(f.kind=="CHECKPOINT"){
  o<<"draws="<<f.draws<<'\n';if(f.draws=="PHILOX")o<<"tier=fixture-r1\nblock="<<f.block<<'\n';
  o<<"u="<<f.u<<'\n';if(f.draws=="INJECTED")o<<"r_t="<<f.rt<<'\n';
  o<<"genotypes="<<arrayhex(f.s.x,8)<<"\ncaches="<<arrayhex(f.s.cache,8)<<"\npolicy_mask="<<hx(f.s.policy,8)<<"\ncache_valid_mask="<<hx(f.s.valid,8)<<"\nt_rec="<<hx(f.rec,8)<<"\nt_inn="<<hx(f.inn,8)<<'\n';if(f.draws=="INJECTED")o<<injected_text(f.tape,"");
 }
 else if(f.kind=="HISTORY"){
  require(f.s.policy==0||f.s.policy==UINT32_MAX,"history start");require(f.steps.size()==f.u&&f.s.valid==0&&cachezeros(f.s),"history writer state");
  o<<"draws=INJECTED\nblock_id="<<f.block<<"\nstart="<<(f.s.policy?"ALL_M":"ALL_F")<<"\nupdates="<<f.u<<"\ngenotypes0="<<arrayhex(f.s.x,8)<<'\n';
  for(unsigned k=1;k<=f.u;++k){auto p="u"+std::to_string(k)+".";auto& s=f.steps[k-1];o<<p<<"innov="<<hx(s.innov,8)<<'\n'<<p<<"copy="<<s.copy<<'\n'<<injected_text(s.tape,p);}
 }
 else if(f.kind=="NUMVEC"){
  o<<"blocks="<<f.n<<"\nconstant="<<sixtext(f.constant)<<"\noverride=";if(f.overrides.empty())o<<"NONE";else{bool first=true;for(auto& v:f.overrides){if(!first)o<<';';o<<v.first<<':'<<sixtext(v.second);first=false;}}o<<'\n';
 }
 else if(f.kind=="CLASSIFIER"){o<<"iv=";for(unsigned j=0;j<6;++j){if(j)o<<',';o<<f.intervals[j].lo.text()<<','<<f.intervals[j].hi.text();}o<<'\n';}
 else throw Error("fixture writer kind");auto text=o.str();read_fixin(bytes(text),f.id);return text;
}
inline std::string classifier_body(const std::array<Interval,6>& iv){auto c=classification(iv);std::ostringstream o;for(unsigned j=0;j<6;++j)o<<"LABEL "<<endpoints()[j]<<' '<<labelname(c.labels[j])<<'\n';if(c.good)o<<derived(iv,c);else o<<"SUMMARY S0_INVALID\n";return o.str();}
inline Six vector_sums(const Fixture& f){Six s{};for(unsigned j=0;j<6;++j)s[j]=f.constant[j]*f.n;for(auto& ov:f.overrides)for(unsigned j=0;j<6;++j)s[j]+=ov.second[j]-f.constant[j];return s;}
inline std::string checkpoint_body(const Checkpoint& c){std::ostringstream o;o<<"eligible_mask="<<hx(c.f.E,8)<<"\ne="<<c.f.e<<"\nH="<<(c.f.e>0)<<"\nfocal_slot="<<hx(c.f.slot,2)<<"\nfocal_key="<<hx(c.f.key,16)<<'\n';for(unsigned a=0;a<6;++a)o<<"arm"<<a<<'='<<hex(c.arms[a])<<'\n';o<<"numerators="<<sixtext(c.nums)<<'\n';return o.str();}
inline std::string fixture_body(const Fixture& f){
 if(f.kind=="LEMIRE"){auto v=lemire(f.W,[&](unsigned r){if(r>=f.xs.size())throw DrawFault("DRAW_EXHAUSTED");return f.xs[r];});return "result="+std::to_string(v.first)+","+hx(v.second,16)+"\n";}
 if(f.kind=="CHECKPOINT")return checkpoint_body(checkpoint(f.s,f.rec,f.inn,f.rt,f.tape));
 if(f.kind=="HISTORY"){State s=f.s;std::array<uint32_t,4> T{};Digest D=digest0(f.block,s);std::ostringstream o;o<<"D_u0="<<hex(D)<<'\n';for(unsigned k=1;k<=f.u;++k){auto& in=f.steps[k-1];T[k]=k>=3&&in.copy?T[k-2]:in.innov;auto foc=focal(s,in.tape.focal);auto step=turnover(s,T[k],0,in.tape,foc,0,1);s=step.state;D=digestnext(D,k,T[k],step.retries,s);o<<"T_u"<<k<<'='<<hx(T[k],8)<<"\nretries_u"<<k<<'='<<step.retries<<"\nS_u"<<k<<'='<<hex(encode(s))<<"\nD_u"<<k<<'='<<hex(D)<<'\n';}return o.str();}
 if(f.kind=="NUMVEC")return inference_body(infer(vector_sums(f),f.n));
 if(f.kind=="CLASSIFIER")return classifier_body(f.intervals);
 throw Error("unknown fixture kind");
}
inline std::string fixout_error(const std::string& id,const std::string& code){require(valid_id(id),"fixture id");return "BRC2-FIXOUT-V1\nfixture_id="+id+"\nstatus=ERROR "+code+"\nEND\n";}
inline std::string make_fixout(const Bytes& input,const std::string& id){
 try {Fixture f=read_fixin(input,id);auto body=fixture_body(f);return "BRC2-FIXOUT-V1\nfixture_id="+id+"\nstatus=OK\n"+body+"END\n";}
 catch(const InputFault& e){return fixout_error(id,e.what());}
 catch(const DrawFault& e){return fixout_error(id,e.what());}
}
struct Fixout {
 std::string status;Checkpoint cp;unsigned retry=0;uint64_t Z=0;
 std::vector<std::string> body;
};
inline State decode_state(const Bytes& b){require(b.size()==264,"state size");State s;for(unsigned i=0;i<32;++i){s.x[i]=uint32_t(get(b,4*i,4));s.cache[i]=uint32_t(get(b,128+4*i,4));}s.policy=uint32_t(get(b,256,4));s.valid=uint32_t(get(b,260,4));return s;}
// Typed FIXOUT reader. The input kind is necessary because FIXOUT omits it.
// Arithmetic/classifier outputs additionally undergo canonical semantic re-render.
inline Fixout read_fixout(const Bytes& b,const std::string& id,const Fixture* input){
 Reader r(b);r.literal("BRC2-FIXOUT-V1");syntax(r.field("fixture_id")==id);Fixout f;auto status=r.field("status");f.status=status;
 if(status!="OK"){syntax(status=="ERROR INPUT_SYNTAX"||status=="ERROR INPUT_RANGE"||status=="ERROR DRAW_EXHAUSTED"||status=="ERROR RETRY_CAP");r.literal("END");r.end();return f;}
 syntax(input!=nullptr);size_t start=r.p;
 if(input->kind=="LEMIRE"){auto l=split(r.field("result"),',');syntax(l.size()==2);f.retry=unsigned(fdec(l[0],0,15));f.Z=fhex(l[1],16);range(f.retry<input->xs.size()&&f.Z<input->W);}
 else if(input->kind=="CHECKPOINT"){
  f.cp.f.E=uint32_t(fhex(r.field("eligible_mask"),8));f.cp.f.e=unsigned(fdec(r.field("e"),0,32));unsigned H=unsigned(fdec(r.field("H"),0,1));f.cp.f.slot=unsigned(fhex(r.field("focal_slot"),2));f.cp.f.key=fhex(r.field("focal_key"),16);
  range(f.cp.f.e==pop(f.cp.f.E)&&H==(f.cp.f.e>0));if(H)range(f.cp.f.slot<32&&((f.cp.f.E>>f.cp.f.slot)&1));else range(f.cp.f.slot==255&&f.cp.f.key==UINT64_MAX);
  for(unsigned a=0;a<6;++a){auto s=r.field("arm"+std::to_string(a));syntax(ishex(s,560));f.cp.arms[a]=unhex(s);}f.cp.nums=sixints(r.field("numerators"));range(armC(f.cp.arms,f.cp.f.E,f.cp.f.slot,input->rt));
 }
 else if(input->kind=="HISTORY"){
  syntax(ishex(r.field("D_u0"),64));for(unsigned k=1;k<=input->u;++k){std::string suffix="_u"+std::to_string(k);fhex(r.field("T"+suffix),8);fdec(r.field("retries"+suffix),0,8160);auto st=r.field("S"+suffix);syntax(ishex(st,528));auto s=decode_state(unhex(st));range(cachezeros(s)&&s.valid==s.policy);syntax(ishex(r.field("D"+suffix),64));}
 }
 else if(input->kind=="NUMVEC"||input->kind=="CLASSIFIER"){
  // Comparing a fresh canonical rendering validates every token, exact fraction,
  // denominator, name order, predicate boundary and the prescribed line count.
  auto expected=lines(bytes(input->kind=="NUMVEC"?inference_body(infer(vector_sums(*input),input->n)):classifier_body(input->intervals)));
  for(auto& line:expected)syntax(r.raw()==line);
 }else syntax(false);
 f.body.assign(r.l.begin()+start,r.l.begin()+r.p);r.literal("END");r.end();return f;
}
struct ConditionalChecks {std::array<bool,6> pass{};bool good()const{return std::all_of(pass.begin(),pass.end(),[](bool b){return b;});}std::string report()const{static const char* names[]={"C_PAYLOAD","E","F_INJECTED","G","H","I"};std::ostringstream o;for(unsigned i=0;i<6;++i)o<<"CONDITIONAL "<<names[i]<<" status="<<(pass[i]?"PASS":"FAIL")<<'\n';o<<"CONDITIONAL_RESULT="<<(good()?"PASS":"FAIL")<<"\nNOT_APPLICABLE=A,B,D,J,K,L\n";return o.str();}};
inline ConditionalChecks cond_forge(const Fixture& f,const Fixout& out){
 // Reapply the complete typed-input validation at the harness call site first.
 require(f.kind=="CHECKPOINT"&&f.draws=="INJECTED"&&f.u==193,"COND_FORGE input applicability");ConditionalChecks c;if(out.status!="OK")return c;
 const auto& cp=out.cp;auto expected=focal(f.s,f.tape.focal);
 c.pass[0]=cp.f.E==expected.E&&cp.f.e==expected.e&&cp.f.slot==expected.slot&&cp.f.key==expected.key&&armC(cp.arms,cp.f.E,cp.f.slot,f.rt)&&staticnums(cp.nums);
 c.pass[1]=f.s.valid==f.s.policy&&cp.f.E==(f.s.policy&f.s.valid);
 Checkpoint replay;bool ready=false;try{replay=checkpoint(f.s,f.rec,f.inn,f.rt,f.tape);ready=true;c.pass[2]=cp.arms==replay.arms;}catch(const DrawFault&){}
 try{auto counted=count_survivors(cp.arms,cp.f.E,cp.f.slot);c.pass[3]=counted.same&&counted.nums==cp.nums&&ready&&counted.nums==replay.nums;}catch(const Error&){}
 c.pass[4]=bounds(cp.nums,cp.f.e);c.pass[5]=identities(cp.arms,cp.nums,cp.f.e,cp.f.e>0);return c;
}
struct BundleItem {std::string id,hash;Bytes input;};
inline std::vector<BundleItem> read_bundle(const fs::path& dir){
 require(fs::is_directory(fs::symlink_status(dir)),"bundle directory");auto index=readfile(dir/"INDEX.txt");auto ls=lines(index);std::vector<BundleItem> items;std::set<std::string> expected{"INDEX.txt"};std::string previous;
 for(auto& s:ls){auto v=split(s,' ');require(v.size()==2&&valid_id(v[0])&&ishex(v[1],64)&&v[0]>previous,"bundle index");previous=v[0];auto name="FIXIN_"+v[0]+".txt";auto b=readfile(dir/name);require(hex(sha(b))==v[1],"FIXIN hash");items.push_back({v[0],v[1],std::move(b)});expected.insert(name);}
 std::set<std::string> seen;for(auto& e:fs::directory_iterator(dir)){require(regular(e.path()),"bundle type");seen.insert(e.path().filename().string());}require(seen==expected&&!items.empty(),"bundle inventory");return items;
}
} // namespace brc
