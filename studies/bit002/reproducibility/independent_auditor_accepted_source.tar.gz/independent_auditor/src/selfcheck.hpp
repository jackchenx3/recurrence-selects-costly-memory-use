#pragma once
#include "fixture.hpp"
namespace brc {
// Future fixture checks only. This source is not executed during construction.
inline void public_kats(const fs::path& kat){auto b=readfile(kat);require(hex(sha(b))=="aab5ebabf40003f63d6d87b24cbd2c8a02652e00cf8bad64226fd50586929183","KAT file identity");std::istringstream input(str(b));std::string line;unsigned n=0;while(std::getline(input,line)){std::istringstream in(line);std::string gen;unsigned rounds=0;if(!(in>>gen>>rounds)||gen!="philox4x32"||rounds!=10)continue;Words ctr{},out{};Key key{};std::string word;for(auto& x:ctr){require(bool(in>>word),"KAT format");x=uint32_t(fhex(word,8));}for(auto& x:key){require(bool(in>>word),"KAT format");x=uint32_t(fhex(word,8));}for(auto& x:out){require(bool(in>>word),"KAT format");x=uint32_t(fhex(word,8));}require(!(in>>word),"KAT extra");require(philox(ctr,key)==out,"Philox KAT");++n;}require(n==3,"KAT count");
 require(hex(sha(std::string()))=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","SHA empty KAT");require(hex(sha(std::string("abc")))=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA abc KAT");require(hex(sha(std::string("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")))=="248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1","SHA multiblock KAT");}
inline std::string key_header(){return "tier\tpurpose\tkey_string\tsha256\tk0_le_u32_hex\tk1_le_u32_hex\tfirst64_le_u64_hex";}
inline std::string keyrow(const Tier& t,Purpose p){auto text=std::string(STUDY)+"|"+t.name+"|"+purposes()[p];auto digest=sha(text);Bytes d(digest.begin(),digest.end());return t.name+"\t"+purposes()[p]+"\t"+text+"\t"+hex(digest)+"\t"+hx(get(d,0,4),8)+"\t"+hx(get(d,4,4),8)+"\t"+hx(get(d,0,8),16);}
inline void public_keys(const fs::path& table){
 // The frozen key artifact is TSV; canonical protocol text readers forbid tabs.
 // Accept TAB only here, then compare every original row byte-for-byte below.
 auto b=readfile(table);require(!b.empty()&&b.back()==10,"key table final LF");
 for(uint8_t c:b)require(c==9||c==10||(c>=32&&c<=126),"key table ASCII");
 auto ls=split(str(b),'\n');ls.pop_back();require(ls.size()==34&&ls[0]==key_header(),"key table shape");std::set<uint64_t> distinct;unsigned row=1;for(auto name:{"production-r1","fixture-r1","benchmark-r1"}){auto t=tier(name);for(unsigned p=0;p<PURPOSES;++p){require(ls[row++]==keyrow(t,Purpose(p)),"independent key agreement");auto k=derive(t,Purpose(p));require(distinct.insert(uint64_t(k[0])|(uint64_t(k[1])<<32)).second,"33-key collision");}}require(distinct.size()==33,"key cardinality");}
inline void expect_coordinate_error(const std::function<void()>& fn){bool rejected=false;try{fn();}catch(const Error&){rejected=true;}require(rejected,"coordinate rejection");}
inline void coordinate_checks(){
 // Address uniqueness follows purpose-separated keys and injective coordinates.
 // Endpoint enumeration exercises every coordinate schema without populations.
 for(auto name:{"production-r1","fixture-r1","benchmark-r1"}){auto tr=tier(name);RNG r(tr);for(unsigned p=0;p<PURPOSES;++p){Purpose purpose=Purpose(p);uint32_t umax=p==INITIAL_GENOTYPE||p==CHECKPOINT_TIME?0:256;uint32_t umin=umax?1:0;uint32_t emax=p==CHECKPOINT_TIME||p==TARGET_INNOVATION||p==TARGET_COPY?0:p==DONOR_KEY?95:31;uint32_t smax=p==LOCAL_BIT?31:p==SURVIVAL_UNIFORM?255:0;
  for(uint32_t b:{0U,tr.n-1})for(uint32_t u:{umin,umax})for(uint32_t e:{0U,emax})for(uint32_t s:{0U,smax}){unsigned use_u=purpose==FOCAL_PARENT?r.checkpoint_update(b):u;auto a=r.at(purpose,b,use_u,e,s);require(a==r.at(purpose,b,use_u,e,s),"coordinate repeat");}
  unsigned base_u=purpose==FOCAL_PARENT?r.checkpoint_update(0):umin;
  expect_coordinate_error([&]{r.at(purpose,tr.n,base_u,0,0);});expect_coordinate_error([&]{r.at(purpose,0,umax+1,0,0);});expect_coordinate_error([&]{r.at(purpose,0,base_u,emax+1,0);});expect_coordinate_error([&]{r.at(purpose,0,base_u,0,smax+1);});if(umax)expect_coordinate_error([&]{r.at(purpose,0,0,0,0);});
 }
 // Within each purpose there is exactly one representation of every logical
 // variable; distinct purposes have distinct keys verified by public_keys.
 // Enumerate the full allowed per-update schemas on fixture block zero.
 if(tr.code==2){std::set<std::array<uint32_t,5>> addresses;
  auto add=[&](Purpose p,unsigned u,unsigned e,unsigned s){require(addresses.insert(std::array<uint32_t,5>{{unsigned(p),0,u,e,s}}).second,"coordinate collision");};
  for(unsigned i=0;i<32;++i)add(INITIAL_GENOTYPE,0,i,0);add(CHECKPOINT_TIME,0,0,0);
  for(unsigned u=1;u<=256;++u){add(TARGET_INNOVATION,u,0,0);add(TARGET_COPY,u,0,0);for(unsigned i=0;i<32;++i){for(auto p:{FRESH_MASK,SCOUT_MASK,POLICY_MUTATION})add(p,u,i,0);for(unsigned bit=0;bit<32;++bit)add(LOCAL_BIT,u,i,bit);for(unsigned retry=0;retry<256;++retry)add(SURVIVAL_UNIFORM,u,i,retry);}for(unsigned j=0;j<96;++j)add(DONOR_KEY,u,j,0);}
  for(unsigned i=0;i<32;++i)add(FOCAL_PARENT,r.checkpoint_update(0),i,0);
  require(addresses.size()==size_t(65)+size_t(256)*(2+96+1024+8192+96),"coordinate cardinality");
 }
 }
}
inline void mapping_and_sharing(){
 auto p=tier("production-r1"),f=tier("fixture-r1"),b=tier("benchmark-r1");require(p.checkpoint(0)==193&&p.checkpoint(63)==256&&f.checkpoint(0)==193&&f.checkpoint(63)==256&&b.checkpoint(0)==256&&b.checkpoint(63)==256,"tier rule");
 RNG r(f,193);auto w=tape(r,3,193);auto again=tape(r,3,193);require(w.fresh==again.fresh&&w.scout==again.scout&&w.local==again.local&&w.donor==again.donor&&w.flip==again.flip&&w.focal==again.focal,"tape invariance");
 // No scientific labels enter RNG/Tape interfaces. For every arm and every draw
 // and retry, verify the same address value, including branch-unused entries.
 for(unsigned arm=0;arm<6;++arm)for(unsigned d=0;d<32;++d)for(unsigned retry=0;retry<256;++retry)require(w.x(d,retry)==again.x(d,retry),"six-arm tape sharing");
}
inline std::string named_id(const fs::path& p,const std::string& prefix){auto s=p.filename().string();require(s.rfind(prefix,0)==0&&s.size()>prefix.size()+4&&s.substr(s.size()-4)==".txt","fixture filename");auto id=s.substr(prefix.size(),s.size()-prefix.size()-4);require(valid_id(id),"fixture id");return id;}
inline void require_new_directory(const fs::path& p){require(!fs::exists(fs::symlink_status(p)),"output directory must be new");require(fs::create_directory(p),"create output directory");}
inline void run_bundle(const fs::path& bundle,const fs::path& out,const std::string& cond_id){
 require(valid_id(cond_id),"COND_FORGE id required");auto items=read_bundle(bundle);require_new_directory(out);std::ostringstream receipt;receipt<<"BRC2-AUDITOR-FIXTURE-RECEIPT-V1\nindex_sha256="<<hex(sha(readfile(bundle/"INDEX.txt")))<<'\n';bool found=false;
 for(auto& item:items){auto output=make_fixout(item.input,item.id);std::unique_ptr<Fixture> input;try{input=std::make_unique<Fixture>(read_fixin(item.input,item.id));}catch(const InputFault&){}if(input)require(bytes(write_fixin(*input))==item.input,"FIXIN canonical round-trip");auto parsed=read_fixout(bytes(output),item.id,input.get());writefile(out/("FIXOUT_"+item.id+".txt"),output);
  receipt<<"FIXTURE "<<item.id<<" grammar=PASS sha256="<<hex(sha(output))<<'\n';
  if(item.id==cond_id){found=true;require(bool(input),"COND_FORGE input missing/invalid");auto c=cond_forge(*input,parsed);receipt<<c.report();require(c.good(),"conditional fixture failure");}
 }
 require(found,"COND_FORGE input absent");receipt<<"FIXOUT_GENERATION=COMPLETE\nCROSS_IMPLEMENTATION=NOT_EVALUATED\n";writefile(out/"RECEIPT.txt",receipt.str());
}
// This separate command reads already-frozen outputs and never regenerates them.
inline void compare_bundle(const fs::path& bundle,const fs::path& own,const fs::path& other,const std::string& cond_id){auto items=read_bundle(bundle);bool found=false;for(auto& item:items){std::unique_ptr<Fixture> input;try{input=std::make_unique<Fixture>(read_fixin(item.input,item.id));}catch(const InputFault&){}auto a=readfile(own/("FIXOUT_"+item.id+".txt")),b=readfile(other/("FIXOUT_"+item.id+".txt"));auto x=read_fixout(a,item.id,input.get());read_fixout(b,item.id,input.get());require(a==b,"FIXOUT byte disagreement");if(item.id==cond_id){found=true;require(bool(input)&&cond_forge(*input,x).good(),"conditional comparison");}}require(found,"COND_FORGE absent");}
} // namespace brc
