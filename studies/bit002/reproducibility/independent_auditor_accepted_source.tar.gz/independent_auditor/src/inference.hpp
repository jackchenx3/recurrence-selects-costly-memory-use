#pragma once
#include "operator.hpp"
#include <boost/multiprecision/cpp_int.hpp>
namespace brc {
using Big=boost::multiprecision::cpp_int;
inline Big absbig(Big a){if(a<0)a=-a;return a;}
inline Big gcd(Big a,Big b){a=absbig(a);b=absbig(b);while(b!=0){Big t=a%b;a=b;b=t;}return a;}
struct Rat {
 Big p=0,q=1;
 Rat()=default;Rat(int64_t a):p(a){}Rat(Big a,Big b):p(a),q(b){require(q!=0,"zero denominator");if(q<0){p=-p;q=-q;}Big g=gcd(p,q);p/=g;q/=g;}
 std::string text()const{return p.convert_to<std::string>()+"/"+q.convert_to<std::string>();}
};
inline Rat operator+(const Rat& a,const Rat& b){return Rat(a.p*b.q+b.p*a.q,a.q*b.q);}
inline Rat operator-(const Rat& a,const Rat& b){return Rat(a.p*b.q-b.p*a.q,a.q*b.q);}
inline Rat operator/(const Rat& a,int64_t b){return Rat(a.p,a.q*b);}
inline Rat operator-(const Rat& a){return Rat(-a.p,a.q);}
inline bool operator<(const Rat& a,const Rat& b){return a.p*b.q<b.p*a.q;}
inline bool operator>(const Rat& a,const Rat& b){return b<a;}
inline bool operator<=(const Rat& a,const Rat& b){return !(b<a);}
inline bool operator==(const Rat& a,const Rat& b){return a.p==b.p&&a.q==b.q;}
inline Big bigint(const std::string& s,bool negative=true){require(!s.empty(),"integer syntax");bool neg=s[0]=='-';require(!neg||negative,"integer syntax");std::string a=neg?s.substr(1):s;require(!a.empty()&&(a=="0"||a[0]!='0')&&!(neg&&a=="0"),"integer syntax");Big n=0;for(char c:a){require(c>='0'&&c<='9',"integer syntax");n*=10;n+=c-'0';}if(neg)n=-n;return n;}
inline Rat fraction(const std::string& s){auto a=split(s,'/');require(a.size()==2,"fraction syntax");Big p=bigint(a[0]),q=bigint(a[1],false);require(q>0&&gcd(p,q)==1,"fraction syntax");return Rat(p,q);}
inline const std::array<std::string,6>& endpoints(){static const std::array<std::string,6> v{{"L_rec","L_inn","P_rec","P_inn","F_rec","F_inn"}};return v;}
inline const std::array<std::string,3>& quantities(){static const std::array<std::string,3> v{{"L","P","F"}};return v;}
inline int64_t static_bound(unsigned j){return j<2?32:j<4?1024:4;}
struct Interval {Rat lo,hi;};
enum Label {MP,MN,NG,PS,NS,FALL};
inline std::string labelname(Label l){static const char* v[]={"MATERIAL_POSITIVE","MATERIAL_NEGATIVE","NEGLIGIBLE_WITHIN_MARGIN","POSITIVE_MAGNITUDE_UNRESOLVED","NEGATIVE_MAGNITUDE_UNRESOLVED","FALLTHROUGH"};return v[l];}
inline Label classify(const Interval& x,unsigned j){Rat d(Big(1),Big(j<4?64:256)),e(Big(1),Big(j<4?32:128));if(x.lo>d)return MP;if(x.hi<-d)return MN;if(x.lo>-e&&x.hi<e)return NG;if(x.lo>Rat(0))return PS;if(x.hi<Rat(0))return NS;return FALL;}
inline bool material(Label a){return a==MP||a==MN;}
inline bool signonly(Label a){return a==PS||a==NS;}
inline std::string pattern(Label r,Label i){
 require(r!=FALL&&i!=FALL,"classification fallthrough");
 if((r==MP&&i==MN)||(r==MN&&i==MP))return "OFFSETTING_MATERIAL";
 if(r==MP&&i==MP)return "CONCORDANT_MATERIAL_POSITIVE";
 if(r==MN&&i==MN)return "CONCORDANT_MATERIAL_NEGATIVE";
 if(material(r)&&i==NG)return std::string("RECURRENT_ONLY_MATERIAL_")+(r==MP?"POSITIVE":"NEGATIVE");
 if(material(i)&&r==NG)return std::string("INNOVATION_ONLY_MATERIAL_")+(i==MP?"POSITIVE":"NEGATIVE");
 if((material(r)&&signonly(i))||(material(i)&&signonly(r))){bool same=((r==MP&&i==PS)||(r==MN&&i==NS)||(i==MP&&r==PS)||(i==MN&&r==NS));return std::string("ONE_MATERIAL_OTHER_SIGN_ONLY_")+(same?"SAME":"OPPOSING");}
 if(r==NG&&i==NG)return "BOTH_NEGLIGIBLE";
 if((r==PS&&i==NS)||(r==NS&&i==PS))return "OPPOSING_SIGNS_NONMATERIAL";
 return "NONMATERIAL_OTHER";
}
inline std::string join(const std::vector<std::string>& v,const std::string& sep=","){std::string s;for(auto& a:v){if(!s.empty())s+=sep;s+=a;}return s;}
struct Classified {std::array<Label,6> labels;std::array<std::string,3> patterns;bool good=true;};
inline Classified classification(const std::array<Interval,6>& iv){Classified c;for(unsigned j=0;j<6;++j){c.labels[j]=classify(iv[j],j);if(c.labels[j]==FALL)c.good=false;}if(c.good)for(unsigned j=0;j<3;++j)c.patterns[j]=pattern(c.labels[2*j],c.labels[2*j+1]);return c;}
inline std::string summary(const Classified& c){
 if(!c.good)return "S0_INVALID";
 std::vector<std::string> names;for(unsigned j=0;j<3;++j)if(c.patterns[j]=="OFFSETTING_MATERIAL")names.push_back(quantities()[j]);if(!names.empty())return "S1_MATERIAL_TARGET_OFFSETTING quantities="+join(names);
 for(unsigned j=0;j<6;++j)if(c.labels[j]==MN)names.push_back(endpoints()[j]);if(!names.empty())return "S2_MATERIAL_ADVERSE_PRESENT endpoints="+join(names);
 for(unsigned j=0;j<6;++j)if(c.labels[j]==MP)names.push_back(endpoints()[j]);if(!names.empty())return "S3_MATERIAL_POSITIVE_ONLY endpoints="+join(names);
 if(std::all_of(c.labels.begin(),c.labels.end(),[](Label a){return a==NG;}))return "S4_ALL_NEGLIGIBLE_WITHIN_MARGIN";
 for(unsigned j=0;j<6;++j)if(signonly(c.labels[j]))names.push_back(endpoints()[j]);require(!names.empty(),"summary fallthrough");return "S5_NONMATERIAL_SIGN_RESOLVED endpoints="+join(names);
}
inline std::string derived(const std::array<Interval,6>& iv,const Classified& c){
 require(c.good,"classification fallthrough");std::ostringstream o;
 for(unsigned j=0;j<3;++j){const auto& r=iv[2*j];const auto& i=iv[2*j+1];Rat dl=r.lo-i.hi,dh=r.hi-i.lo;
  o<<"DERIVED "<<quantities()[j]<<" avg_lo="<<((r.lo+i.lo)/2).text()<<" avg_hi="<<((r.hi+i.hi)/2).text()<<" diff_lo="<<dl.text()<<" diff_hi="<<dh.text()<<" resolved_difference="<<(dl>Rat(0)||dh<Rat(0))<<'\n';o<<"PATTERN "<<quantities()[j]<<' '<<c.patterns[j]<<'\n';}
 o<<"SUMMARY "<<summary(c)<<'\n';return o.str();
}
struct Inference {Six sums{};std::array<uint64_t,6> den{};std::array<Rat,6> means;std::array<Interval,6> iv;Classified c;};
inline Inference infer(const Six& sums,uint32_t n){
 require(n>=1&&n<=42000,"inference size");Inference a;a.sums=sums;
 Rat hp(Big("15608294208001326"),Big("1000000000000000000")),hf(Big("2378115509733596"),Big("1000000000000000000"));
 for(unsigned j=0;j<6;++j){require(sums[j]>=-static_bound(j)*int64_t(n)&&sums[j]<=static_bound(j)*int64_t(n),"sum range");a.den[j]=uint64_t(n)*(j==2||j==3?1024:32);a.means[j]=Rat(Big(sums[j]),Big(a.den[j]));Rat h=j<4?hp:hf,cap=j<4?Rat(1):Rat(Big(1),Big(8));a.iv[j]={std::max(-cap,a.means[j]-h),std::min(cap,a.means[j]+h)};require(a.iv[j].lo<=a.iv[j].hi,"interval");}
 a.c=classification(a.iv);require(a.c.good,"classification fallthrough");return a;
}
inline std::string inference_body(const Inference& a){std::ostringstream o;for(unsigned j=0;j<6;++j)o<<"ENDPOINT "<<endpoints()[j]<<" sum="<<a.sums[j]<<" den="<<a.den[j]<<" mean="<<a.means[j].text()<<" lo="<<a.iv[j].lo.text()<<" hi="<<a.iv[j].hi.text()<<" label="<<labelname(a.c.labels[j])<<'\n';o<<derived(a.iv,a.c);return o.str();}
struct Descriptions {std::array<uint64_t,2> H{},R{},factualA{};std::array<std::array<uint64_t,33>,2> e{};std::array<Six,2> sums{};};
inline std::string render_valid(const Tier& t,const std::string& manifest,const Inference& a,const Descriptions& d){
 std::ostringstream o;o<<"BRC2-RESULTS-V3\nstatus=VALID\ntier="<<t.name<<"\nmanifest_sha256="<<manifest<<"\nblocks="<<t.n<<'\n'<<inference_body(a);
 o<<"DESC H_count ALL_F="<<d.H[0]<<" ALL_M="<<d.H[1]<<'\n';
 for(unsigned s=0;s<2;++s){o<<"DESC E_hist "<<(s?"ALL_M":"ALL_F")<<'=';for(unsigned e=0;e<=32;++e){if(e)o<<',';o<<d.e[s][e];}o<<'\n';}
 o<<"DESC R1_count ALL_F="<<d.R[0]<<" ALL_M="<<d.R[1]<<'\n';for(unsigned s=0;s<2;++s){o<<"DESC startsum "<<(s?"ALL_M":"ALL_F");for(unsigned j=0;j<6;++j)o<<' '<<endpoints()[j]<<'='<<d.sums[s][j];o<<'\n';}o<<"DESC factual_A_sum ALL_F="<<d.factualA[0]<<" ALL_M="<<d.factualA[1]<<"\nEND\n";return o.str();
}
} // namespace brc
