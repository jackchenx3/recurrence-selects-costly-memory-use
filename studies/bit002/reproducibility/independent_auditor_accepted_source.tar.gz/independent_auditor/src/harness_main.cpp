#include "corruption.hpp"
int main(int argc,char** argv){using namespace brc;const char* public_stage=nullptr;try{
 require(argc>=2,"mode required");std::string mode=argv[1];std::map<std::string,std::string> a;for(int i=2;i<argc;++i){std::string k=argv[i];require(k.rfind("--",0)==0&&!a.count(k)&&i+1<argc,"argument");a[k]=argv[++i];}
 auto exact=[&](std::initializer_list<const char*> keys){require(a.size()==keys.size(),"arguments");for(auto k:keys)require(a.count(k),"missing argument");};
 if(mode=="public-checks"){exact({"--kat","--keys"});public_stage="public_kats";public_kats(a["--kat"]);public_stage="public_keys";public_keys(a["--keys"]);public_stage="coordinate_checks";coordinate_checks();public_stage="mapping_and_sharing";mapping_and_sharing();std::cout<<"PUBLIC_CHECKS=PASS\n";}
 else if(mode=="fixout"){exact({"--bundle","--out-dir","--cond-forge-id"});run_bundle(a["--bundle"],a["--out-dir"],a["--cond-forge-id"]);std::cout<<"FIXOUT_GENERATION=COMPLETE\n";}
 else if(mode=="compare"){exact({"--bundle","--own-dir","--other-dir","--cond-forge-id"});compare_bundle(a["--bundle"],a["--own-dir"],a["--other-dir"],a["--cond-forge-id"]);std::cout<<"FIXOUT_EQUAL=1\n";}
 else if(mode=="corrupt"){exact({"--data","--scratch"});run_corruptions(a["--data"],a["--scratch"]);std::cout<<"CORRUPTION_SUITE=PASS\n";}
 else if(mode=="compare-results"){exact({"--own","--other"});auto own=readfile(a["--own"]),other=readfile(a["--other"]);require(sha(own)==sha(other),"result hash disagreement");std::cout<<"RESULTS_HASH_EQUAL=1\n";}
 else throw Error("mode");return 0;
 }catch(const std::exception& e){std::cerr<<"fixture_harness_failure";if(public_stage)std::cerr<<" stage="<<public_stage<<" reason="<<e.what();std::cerr<<'\n';return 1;}}
