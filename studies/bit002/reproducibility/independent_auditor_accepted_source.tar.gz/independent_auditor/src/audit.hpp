#pragma once
#include "inference.hpp"
namespace brc {
struct CheckStatus {bool evaluated=false,failed=false;std::set<uint32_t> ids;};
struct Checks {
 std::array<CheckStatus,12> c;
 void begin(char l){c[l-'A'].evaluated=true;}
 void fail(char l){begin(l);c[l-'A'].failed=true;}
 void fail(char l,uint32_t b){fail(l);c[l-'A'].ids.insert(b);}
 template<class F> void test(char l,uint32_t b,F f){begin(l);try{if(!f())fail(l,b);}catch(const Error&){fail(l,b);}}
 bool bad()const{for(auto& a:c)if(a.failed)return true;return false;}
 std::string failed()const{std::vector<std::string> v;for(unsigned i=0;i<12;++i)if(c[i].failed)v.push_back(std::string(1,char('A'+i)));return join(v);}
 std::string report()const{std::ostringstream o;for(unsigned i=0;i<12;++i){auto& a=c[i];o<<"CHECK "<<char('A'+i)<<" status="<<(!a.evaluated?"NOT_EVALUATED":a.failed?"FAIL":"PASS")<<" failing_blocks="<<a.ids.size()<<" first_ids=";if(a.ids.empty())o<<"NONE";else{unsigned n=0;for(auto b:a.ids){if(n==64)break;if(n)o<<',';o<<b;++n;}}o<<'\n';}o<<"AUDITOR_RESULT="<<(bad()?"FAIL":"PASS")<<'\n';return o.str();}
};
struct Dataset {
 Tier tr;std::string manifest_hash="NONE",build;Bytes manifest;uint64_t declared_queries=0;
 std::vector<Bytes> records;std::vector<std::vector<Digest>> traces;
 explicit Dataset(Tier t):tr(t){}
};
inline std::string chunkname(unsigned k){return "chunk_"+hx(k/10,1)+hx(k%10,1)+".bin";}
inline bool regular(const fs::path& p){return fs::is_regular_file(fs::symlink_status(p));}
inline void loadA(const fs::path& dir,Dataset& d,const RNG& rng) {
 // Capture the manifest hash whenever its bytes are readable, even on a failed A.
 try {d.manifest=readfile(dir/"MANIFEST.txt");d.manifest_hash=hex(sha(d.manifest));}catch(const Error&){d.manifest_hash="NONE";}
 require(fs::is_directory(fs::symlink_status(dir)),"data directory");
 std::set<std::string> want{"MANIFEST.txt","MANIFEST.sha256","trace_audit_blocks.bin"};for(unsigned k=0;k<d.tr.chunks();++k)want.insert(chunkname(k));
 std::set<std::string> seen;for(auto& ent:fs::directory_iterator(dir)){require(regular(ent.path()),"inventory file type");seen.insert(ent.path().filename().string());}require(seen==want,"inventory");
 require(d.manifest_hash!="NONE","manifest unreadable");auto l=lines(d.manifest);unsigned k=d.tr.chunks();require(l.size()==12+k,"manifest lines");
 require(l[0]=="BRC2-MANIFEST-V2"&&l[1]==std::string("study=")+STUDY&&l[2]==std::string("protocol_sha256=")+PROTOCOL&&l[3]=="tier="+d.tr.name,"manifest identity");
 require(l[4].rfind("producer_build_id=",0)==0,"manifest build");d.build=l[4].substr(18);require(ishex(d.build,64),"build syntax");
 require(l[5]=="blocks="+std::to_string(d.tr.n)&&l[6]=="chunk_blocks=1000"&&l[7]=="chunks="+std::to_string(k)&&l[8]=="record_length=2088","manifest shape");
 auto ms=readfile(dir/"MANIFEST.sha256",128);require(str(ms)==d.manifest_hash+"  MANIFEST.txt\n","manifest hash");auto build=unhex(d.build);
 d.records.reserve(d.tr.n);
 for(unsigned q=0;q<k;++q){uint32_t first=1000*q,count=std::min(1000U,d.tr.n-first);uint64_t size=64+uint64_t(2088)*count;Bytes b=readfile(dir/chunkname(q),size);require(b.size()==size,"chunk size");
  require(l[9+q]=="file "+chunkname(q)+" "+std::to_string(size)+" "+hex(sha(b)),"chunk manifest entry");
  require(str(slice(b,0,8))=="BRC2CHNK"&&get(b,8,2)==2&&get(b,10,2)==q&&get(b,12,4)==first&&get(b,16,4)==count&&get(b,20,4)==2088&&get(b,24,4)==d.tr.code&&get(b,28,4)==0&&slice(b,32,32)==build,"chunk header");
  for(uint32_t j=0;j<count;++j){Bytes r=slice(b,64+2088*j,2088);require(get(r,8,4)==first+j,"block inventory");d.records.push_back(std::move(r));}
 }
 // The trace's shape is fixed from the tier and the checkpoint key, independent
 // of potentially forged record checkpoint fields (those are C/D).
 std::vector<unsigned> tvals;uint64_t size=32;
 for(uint32_t b=0;b<d.tr.trace;++b){unsigned t=d.tr.checkpoint(rng.word(CHECKPOINT_TIME,b,0,0));tvals.push_back(t);size+=8+32*t;}
 Bytes tr=readfile(dir/"trace_audit_blocks.bin",size);require(tr.size()==size,"trace size");
 require(l[9+k]=="file trace_audit_blocks.bin "+std::to_string(size)+" "+hex(sha(tr)),"trace manifest entry");
 require(str(slice(tr,0,8))=="BRC2TRCE"&&get(tr,8,2)==2&&get(tr,10,2)==d.tr.trace&&get(tr,12,4)==d.tr.code&&slice(tr,16,16)==Bytes(16,0),"trace header");
 size_t p=32;for(uint32_t b=0;b<d.tr.trace;++b){unsigned t=tvals[b];require(get(tr,p,4)==b&&get(tr,p+4,2)==t&&get(tr,p+6,2)==t,"trace block header");p+=8;std::vector<Digest> v;for(unsigned u=0;u<t;++u){Digest h{};std::copy_n(tr.begin()+p,32,h.begin());p+=32;v.push_back(h);}d.traces.push_back(std::move(v));}require(p==tr.size(),"trace length");
 require(l[10+k].rfind("total_queries=",0)==0,"manifest total");d.declared_queries=decimal(l[10+k].substr(14));require(l[11+k]=="complete=1","manifest incomplete");
}
inline bool checkB(const Bytes& r){return r.size()==2088&&str(slice(r,0,4))=="BRC2"&&get(r,4,2)==2&&get(r,6,2)==2088&&eq(r,2056,sha(slice(r,0,2056)));}
inline bool cachezeros(const State& s){for(unsigned i=0;i<32;++i)if(!((s.valid>>i)&1)&&s.cache[i]!=0)return false;return true;}
inline bool armC(const std::array<Bytes,6>& arms,uint32_t E,unsigned slot,unsigned rt){
 if(rt>1||!(slot<32||slot==255))return false;
 for(unsigned a=0;a<6;++a){auto& v=arms[a];if(v.size()!=280)return false;
  uint32_t Q=a%3==0?0:a%3==1?E:slot==255?0:uint32_t(1)<<slot;
  if(get(v,0,1)!=a||get(v,1,1)!=a/3||get(v,2,1)!=a%3||get(v,3,1)!=(a==(rt?0U:3U))||get(v,4,4)!=Q||get(v,8,2)!=128||get(v,10,2)>8160||get(v,12,1)>32||get(v,13,1)>4||get(v,14,2)>1024||get(v,20,4)>4096)return false;
  std::array<bool,128> seen{};uint32_t mask=0;
  for(unsigned s=0;s<32;++s){size_t p=24+8*s;unsigned j=unsigned(get(v,p,1)),m=unsigned(get(v,p+1,1)),pol=unsigned(get(v,p+2,1));if(j>=128||seen[j]||m>32||pol>1)return false;seen[j]=true;if(pol)mask|=uint32_t(1)<<s;}
  if(get(v,16,4)!=mask)return false;
 }
 return true;
}
inline bool staticnums(const Six& n){for(unsigned j=0;j<6;++j)if(n[j]<-static_bound(j)||n[j]>static_bound(j))return false;return true;}
inline bool checkC(const Bytes& r,const Tier& t){
 uint32_t b=uint32_t(get(r,8,4)),E=uint32_t(get(r,36,4));unsigned rt=unsigned(get(r,13,1)),u=unsigned(get(r,14,2)),e=unsigned(get(r,40,1)),H=unsigned(get(r,41,1)),f=unsigned(get(r,42,1));
 if(get(r,12,1)!=(b&1)||rt>1||get(r,43,1)!=1-rt||u<193||u>256||u!=t.checkpoint(uint32_t(get(r,16,4)))||e!=pop(E)||H!=(e>0))return false;
 if(H){if(f>=32||!((E>>f)&1))return false;}else if(f!=255||get(r,44,8)!=UINT64_MAX)return false;
 if(get(r,60,4)!=128*(u-1)||get(r,64,4)!=768||get(r,2048,4)!=128*(u+5)||get(r,2052,4)!=0||get(r,68,4)>uint64_t(u-1)*8160)return false;
 if(!cachezeros(prestate(r))||!armC(recordarms(r),E,f,rt)||!staticnums(recordnums(r)))return false;return true;
}
inline bool checkD(const Bytes& r,const RNG& rng){uint32_t b=uint32_t(get(r,8,4)),word=rng.word(CHECKPOINT_TIME,b,0,0);unsigned u=rng.contract().checkpoint(word);unsigned rt=rng.word(TARGET_COPY,b,u,0)&1;uint32_t I=rng.word(TARGET_INNOVATION,b,u,0);if(get(r,16,4)!=word||get(r,14,2)!=u||get(r,13,1)!=rt||get(r,28,4)!=I||get(r,32,4)!=(rt?get(r,20,4):I))return false;
 std::array<uint64_t,32> keys{};for(unsigned i=0;i<32;++i)keys[i]=rng.wide(FOCAL_PARENT,b,u,i);
 // D is the argmin over the stored E, independently of E's check-E relation.
 State s;s.policy=uint32_t(get(r,36,4));s.valid=s.policy;auto f=focal(s,keys);return get(r,42,1)==f.slot&&get(r,44,8)==f.key;
}
inline bool checkE(const Bytes& r){auto s=prestate(r);return s.valid==s.policy&&get(r,36,4)==(s.policy&s.valid);}
struct FromSurvivors {std::array<Bytes,6> counted;Six nums{};bool same=true;};
// Independent of candidate generation and selection: count only saved survivors.
inline FromSurvivors count_survivors(const std::array<Bytes,6>& arms,uint32_t E,unsigned focal_slot){FromSurvivors c;c.counted=arms;
 for(unsigned a=0;a<6;++a){unsigned de=0,df=0,acc=0,retries=0;for(unsigned s=0;s<32;++s){unsigned j=unsigned(get(arms[a],24+8*s,1)),m=unsigned(get(arms[a],25+8*s,1));require(j<128&&m<=32,"survivor range");unsigned p=j%32;de+=(E>>p)&1;df+=(p==focal_slot);acc+=32-m;retries+=unsigned(get(arms[a],27+8*s,1));}
  if(get(arms[a],12,1)!=de||get(arms[a],13,1)!=df||get(arms[a],14,2)!=acc||get(arms[a],10,2)!=retries)c.same=false;put(c.counted[a],12,de,1);put(c.counted[a],13,df,1);put(c.counted[a],14,acc,2);put(c.counted[a],10,retries,2);
 }c.nums=numerators(c.counted);return c;
}
inline bool bounds(const Six& n,unsigned e){if(e>32)return false;int64_t bound=std::min({32U,4*e,128-4*e});return n[0]>=-bound&&n[0]<=bound&&n[1]>=-bound&&n[1]<=bound&&n[2]>=-1024&&n[2]<=1024&&n[3]>=-1024&&n[3]<=1024&&n[4]>=-4&&n[4]<=4&&n[5]>=-4&&n[5]<=4;}
inline bool identities(const std::array<Bytes,6>& a,const Six& n,unsigned e,unsigned H){auto same=[&a](unsigned i,unsigned j){return slice(a[i],8,272)==slice(a[j],8,272);};if(H==0){if(!same(0,1)||!same(0,2)||!same(3,4)||!same(3,5))return false;for(auto v:n)if(v!=0)return false;}if(e==1&&(!same(1,2)||!same(4,5)))return false;return true;}
struct AuditRun {Checks checks;std::string results,report;std::string manifest_hash="NONE";double k_seconds=0;};
inline std::string invalid(const Tier& t,const std::string& mh,const Checks& c){return "BRC2-RESULTS-V3\nstatus=INVALID\ntier="+t.name+"\nmanifest_sha256="+mh+"\nfailed_checks="+c.failed()+"\nSUMMARY S0_INVALID\nEND\n";}
inline AuditRun audit(const Tier& t,const fs::path& dir){
 AuditRun run;auto& checks=run.checks;Dataset data(t);RNG rng(t);checks.begin('A');
 try{loadA(dir,data,rng);}catch(const Error&){checks.fail('A');}catch(const fs::filesystem_error&){checks.fail('A');}run.manifest_hash=data.manifest_hash;
 if(!checks.bad()){for(uint32_t b=0;b<t.n;++b)checks.test('B',b,[&]{return checkB(data.records[b]);});}
 if(!checks.bad()){
  for(char l='C';l<='K';++l)checks.begin(l);uint64_t total=0,expected_total=0;
  for(uint32_t b=0;b<t.n;++b){auto& r=data.records[b];auto arms=recordarms(r);auto ns=recordnums(r);uint32_t E=uint32_t(get(r,36,4));unsigned e=unsigned(get(r,40,1)),H=unsigned(get(r,41,1)),slot=unsigned(get(r,42,1)),u=unsigned(get(r,14,2));
   checks.test('C',b,[&]{return checkC(r,t);});checks.test('D',b,[&]{return checkD(r,rng);});checks.test('E',b,[&]{return checkE(r);});
   Checkpoint replay;bool replayed=false;
   checks.test('F',b,[&]{require(u>=193&&u<=256&&get(r,13,1)<=1,"checkpoint range");auto w=tape(rng,b,u);replay=checkpoint(prestate(r),uint32_t(get(r,20,4)),uint32_t(get(r,28,4)),unsigned(get(r,13,1)),w);replayed=true;return replay.arms==arms;});
   checks.test('G',b,[&]{auto counted=count_survivors(arms,E,slot);if(!counted.same||counted.nums!=ns||!replayed||counted.nums!=replay.nums)return false;for(unsigned a=0;a<6;++a)if(get(counted.counted[a],12,1)!=get(replay.arms[a],12,1)||get(counted.counted[a],13,1)!=get(replay.arms[a],13,1)||get(counted.counted[a],14,2)!=get(replay.arms[a],14,2))return false;return true;});
   checks.test('H',b,[&]{return bounds(ns,e);});checks.test('I',b,[&]{return identities(arms,ns,e,H);});
   checks.test('J',b,[&]{if(u<193||u>256||get(r,60,4)!=128*(u-1)||get(r,64,4)!=768||get(r,2048,4)!=128*(u+5))return false;for(auto& a:arms)if(get(a,8,2)!=128)return false;return true;});
   total+=get(r,2048,4);expected_total+=128*(t.checkpoint(rng.word(CHECKPOINT_TIME,b,0,0))+5);
   if(b<t.trace){auto start=Clock::now();checks.test('K',b,[&]{require(u>=193&&u<=256&&u==t.checkpoint(rng.word(CHECKPOINT_TIME,b,0,0)),"history checkpoint");auto h=history(rng,b,u);return encode(h.s)==encode(prestate(r))&&get(r,20,4)==h.targets[u-2]&&get(r,24,4)==h.targets[u-1]&&get(r,68,4)==h.retries&&eq(r,72,h.trace.back())&&data.traces[b]==h.trace;});run.k_seconds+=seconds(start,Clock::now());}
  }
  if(total!=data.declared_queries||total!=expected_total||(t.code==3&&total!=34209792ULL))checks.fail('J');
 }
 if(!checks.bad()){
  checks.begin('L');try{Six sum{};Descriptions desc;
   for(uint32_t b=0;b<t.n;++b){const auto& r=data.records[b];auto n=recordnums(r);unsigned s=b&1,e=unsigned(get(r,40,1)),rt=unsigned(get(r,13,1));for(unsigned j=0;j<6;++j){sum[j]+=n[j];desc.sums[s][j]+=n[j];}desc.H[s]+=get(r,41,1);++desc.e[s][e];desc.R[s]+=rt;desc.factualA[s]+=get(r,360+280*(rt?0:3)+14,2);}
   auto a=infer(sum,t.n);run.results=render_valid(t,data.manifest_hash,a,desc);auto l=lines(bytes(run.results));require(l.size()==26&&l.back()=="END","render grammar");
  }catch(const Error&){checks.fail('L');run.results.clear();}
 }
 if(checks.bad())run.results=invalid(t,data.manifest_hash,checks);run.report=checks.report();return run;
}
// Make hashing observably occur even when timing-only discards rendered bytes.
inline void hash_and_discard(const std::string& s){auto h=sha(s);volatile uint8_t sink=0;for(auto c:h)sink=uint8_t(sink^c);(void)sink;}
} // namespace brc
