#pragma once
#include "selfcheck.hpp"
namespace brc {
inline void copy_fixture_data(const fs::path& source,const fs::path& target){require_new_directory(target);for(auto& e:fs::directory_iterator(source)){require(regular(e.path()),"source inventory type");writefile(target/e.path().filename(),readfile(e.path()),0600);}}
inline void refresh_manifest(const fs::path& dir){auto l=lines(readfile(dir/"MANIFEST.txt"));for(auto& line:l)if(line.rfind("file ",0)==0){auto v=split(line,' ');require(v.size()==4,"manifest line");auto b=readfile(dir/v[1]);line="file "+v[1]+" "+std::to_string(b.size())+" "+hex(sha(b));}std::string text=join(l,"\n")+"\n";writefile(dir/"MANIFEST.txt",text,0600);writefile(dir/"MANIFEST.sha256",hex(sha(text))+"  MANIFEST.txt\n",0600);}
inline void mutate_record(const fs::path& dir,unsigned b,const std::function<void(Bytes&)>& change,bool hashes){auto path=dir/"chunk_00.bin";Bytes chunk=readfile(path);Bytes r=slice(chunk,64+2088*b,2088);change(r);require(r.size()==2088,"corruption record size");if(hashes){auto h=sha(slice(r,0,2056));std::copy(h.begin(),h.end(),r.begin()+2056);}std::copy(r.begin(),r.end(),chunk.begin()+64+2088*b);writefile(path,chunk,0600);if(hashes)refresh_manifest(dir);}
inline bool failed_letter(const AuditRun& r,char l){return r.checks.c[l-'A'].failed;}
inline bool passed_letter(const AuditRun& r,char l){auto& c=r.checks.c[l-'A'];return c.evaluated&&!c.failed;}
inline void run_corruptions(const fs::path& source,const fs::path& scratch){
 auto tr=tier("fixture-r1");auto baseline=audit(tr,source);require(!baseline.checks.bad(),"fixture baseline audit");require_new_directory(scratch);std::ostringstream receipt;receipt<<"BRC2-AUDITOR-CORRUPTIONS-V1\nBASELINE=PASS\n";RNG rng(tr);
 auto one=[&](const std::string& name,const std::function<void(const fs::path&)>& mutate,const std::function<bool(const AuditRun&)>& expected){fs::path path=scratch/"case";copy_fixture_data(source,path);mutate(path);auto result=audit(tr,path);bool ok=expected(result);receipt<<"CASE "<<name<<" status="<<(ok?"PASS":"FAIL")<<" failed_checks="<<result.checks.failed()<<'\n';writefile(scratch/"RECEIPT.txt",receipt.str(),0600);if(!ok){writefile(scratch/"FAILED_AUDIT_REPORT.txt",result.report,0600);throw Error("corruption expectation failed; preserved case");}fs::remove_all(path);};
 auto raw=[](const AuditRun& r){return failed_letter(r,'A')||failed_letter(r,'B');};
 // Offsets cover every header field, the arrays, each arm's metadata/payload,
 // the numerator/integrity fields, and all survivor field categories.
 std::vector<size_t> regions{0,4,6,8,12,13,14,16,20,24,28,32,36,40,41,42,43,44,52,56,60,64,68,72,104,232,2040,2041,2042,2044,2046,2047,2048,2052,2056};
 for(unsigned arm=0;arm<6;++arm){size_t p=360+280*arm;for(size_t o:{0U,1U,2U,3U,4U,8U,10U,12U,13U,14U,16U,20U,24U,25U,26U,27U,28U})regions.push_back(p+o);}
 for(unsigned b=0;b<16;++b)for(auto off:regions)one("RAW_B"+std::to_string(b)+"_OFF"+std::to_string(off),[=](const fs::path& d){mutate_record(d,b,[=](Bytes& r){r[off]^=1;},false);},raw);
 one("TRUNCATION",[](const fs::path& d){auto p=d/"chunk_00.bin";auto b=readfile(p);b.pop_back();writefile(p,b,0600);},raw);
 one("DUPLICATE_RECORD",[](const fs::path& d){auto p=d/"chunk_00.bin";auto b=readfile(p);std::copy_n(b.begin()+64,2088,b.begin()+64+2088);writefile(p,b,0600);},raw);
 one("SWAPPED_RECORDS",[](const fs::path& d){auto p=d/"chunk_00.bin";auto b=readfile(p);for(unsigned i=0;i<2088;++i)std::swap(b[64+i],b[64+2088+i]);writefile(p,b,0600);},raw);
 one("WRONG_RECORD_LENGTH",[](const fs::path& d){mutate_record(d,3,[](Bytes& r){put(r,6,2087,2);},false);},raw);
 one("REHASHED_WRONG_LENGTH",[](const fs::path& d){mutate_record(d,3,[](Bytes& r){put(r,6,2087,2);},true);},[](const AuditRun& r){return passed_letter(r,'A')&&failed_letter(r,'B');});
 one("MISSING_CHUNK",[](const fs::path& d){fs::remove(d/"chunk_00.bin");},raw);
 one("EXTRA_FILE",[](const fs::path& d){writefile(d/"EXTRA",std::string("x\n"),0600);},raw);
 one("LEFTOVER_TEMP",[](const fs::path& d){writefile(d/".tmp.chunk_00.bin",std::string("x\n"),0600);},raw);
 one("MANIFEST_TAMPERING",[](const fs::path& d){auto p=d/"MANIFEST.txt";auto b=readfile(p);b[0]^=1;writefile(p,b,0600);},raw);
 one("SYMLINK",[](const fs::path& d){fs::remove(d/"chunk_00.bin");fs::create_symlink("trace_audit_blocks.bin",d/"chunk_00.bin");},raw);
 one("SUBDIRECTORY",[](const fs::path& d){fs::create_directory(d/"unexpected");},raw);
 auto semantic=[&](const std::string& name,const std::function<void(Bytes&)>& change,const std::string& letters){one(name,[&](const fs::path& d){mutate_record(d,3,change,true);},[&](const AuditRun& r){if(!passed_letter(r,'A')||!passed_letter(r,'B'))return false;for(char c:letters)if(!failed_letter(r,c))return false;return true;});};
 semantic("SURVIVOR_MISMATCH",[](Bytes& r){size_t p=360+25;put(r,p,(get(r,p,1)+1)%33,1);},"FG");
 semantic("SURVIVOR_GENOTYPE",[](Bytes& r){r[360+28]^=1;},"F");
 semantic("CANDIDATE_INDEX",[](Bytes& r){r[360+24]=255;},"C");
 semantic("NUMERATOR",[](Bytes& r){int64_t old=recordnums(r)[0];put(r,2040,uint64_t(old==32?31:old+1),1);},"G");
 semantic("FOCAL_SLOT",[](Bytes& r){r[42]=r[42]==255?0:255;},"D");
 semantic("FOCAL_KEY",[](Bytes& r){r[44]^=1;},"D");
 // Produce an internally coherent H=0 state before corrupting only its sentinel.
 semantic("H0_NONZERO_FOCAL_KEY",[&](Bytes& r){put(r,36,0,4);put(r,40,0,1);put(r,41,0,1);put(r,42,255,1);put(r,44,UINT64_MAX,8);put(r,52,0,4);put(r,56,0,4);for(unsigned i=0;i<32;++i)put(r,232+4*i,0,4);rearm(r,rng);put(r,44,1,8);},"CD");
 semantic("NONZERO_INVALID_CACHE",[&](Bytes& r){unsigned i=0;uint32_t mask=uint32_t(get(r,56,4));while(i<32&&((mask>>i)&1))++i;if(i==32){i=0;put(r,56,mask&~1U,4);}put(r,232+4*i,1,4);},"C");
 semantic("CHECKPOINT_WORD",[](Bytes& r){r[19]^=128;},"D");
 semantic("CHECKPOINT_T",[](Bytes& r){unsigned u=unsigned(get(r,14,2));put(r,14,u==256?193:u+1,2);},"D");
 semantic("START_CODE",[](Bytes& r){r[12]^=1;},"C");
 semantic("R_T",[](Bytes& r){r[13]^=1;},"D");
 semantic("SWITCHED_MASK",[](Bytes& r){r[360+4]^=1;},"C");
 semantic("SWAPPED_ARMS",[](Bytes& r){for(unsigned i=0;i<280;++i)std::swap(r[360+i],r[640+i]);},"C");
 semantic("QUERY_COUNT",[](Bytes& r){put(r,360+8,127,2);},"CJ");
 one("FORGE_CACHE",[&](const fs::path& d){mutate_record(d,3,[&](Bytes& r){uint32_t E=uint32_t(get(r,36,4));require(E!=0,"FORGE_CACHE requires eligible M in block 3");unsigned i=0;while(!((E>>i)&1))++i;r[232+4*i]^=1;rearm(r,rng);},true);},[](const AuditRun& r){for(char c='A';c<='J';++c)if(!passed_letter(r,c))return false;return failed_letter(r,'K')&&!r.checks.c['L'-'A'].evaluated;});
 receipt<<"CORRUPTION_SUITE=PASS\n";writefile(scratch/"RECEIPT.txt",receipt.str(),0400);
}
} // namespace brc
