#include "fixture.hpp"
int main(int argc,char** argv){using namespace brc;try{
 std::map<std::string,std::string> a;for(int i=1;i<argc;++i){std::string k=argv[i];require(k=="--in"||k=="--out","argument");require(!a.count(k)&&i+1<argc,"argument");a[k]=argv[++i];}require(a.size()==2,"arguments");fs::path p=a["--in"];auto name=p.filename().string();require(name.size()>10&&name.rfind("FIXIN_",0)==0&&name.substr(name.size()-4)==".txt","input name");auto id=name.substr(6,name.size()-10);require(valid_id(id),"fixture id");auto input=readfile(p);auto output=make_fixout(input,id);
 // Also validate generated grammar using the typed reader. Malformed FIXIN has
 // an ERROR form, for which the reader intentionally needs no kind context.
 std::unique_ptr<Fixture> f;try{f=std::make_unique<Fixture>(read_fixin(input,id));}catch(const InputFault&){}read_fixout(bytes(output),id,f.get());writefile(a["--out"],output);return 0;
 }catch(const std::exception&){std::cerr<<"usage_or_environment_error\n";return 2;}}
