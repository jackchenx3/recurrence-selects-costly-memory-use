#!/usr/bin/env python3
"""Public seed metadata only: standard hashlib SHA-256; no scientific imports.

Writes INDEPENDENT_33_KEYS.tsv in this file's directory. It neither derives
Philox output nor reads other authors' keys. Legacy comparisons are pending the
separately supplied sanitized manifest and are intentionally not performed here.
"""
import hashlib
from pathlib import Path

STUDY = "PHASE3-BIT-RETRIEVAL-CAUSALITY-002"
TIERS = ("production-r1", "fixture-r1", "benchmark-r1")
PURPOSES = (
    "INITIAL_GENOTYPE", "CHECKPOINT_TIME", "TARGET_INNOVATION", "TARGET_COPY",
    "FRESH_MASK", "SCOUT_MASK", "LOCAL_BIT", "DONOR_KEY", "SURVIVAL_UNIFORM",
    "POLICY_MUTATION", "FOCAL_PARENT",
)


def main():
    rows = ["tier\tpurpose\tkey_string\tsha256\tk0_le_u32_hex\tk1_le_u32_hex\tfirst64_le_u64_hex"]
    keys = set()
    for tier in TIERS:
        for purpose in PURPOSES:
            text = f"{STUDY}|{tier}|{purpose}"
            digest = hashlib.sha256(text.encode("ascii")).digest()
            k0 = int.from_bytes(digest[:4], "little")
            k1 = int.from_bytes(digest[4:8], "little")
            first64 = int.from_bytes(digest[:8], "little")
            if first64 in keys:
                raise RuntimeError("public 33-key metadata collision")
            keys.add(first64)
            rows.append(f"{tier}\t{purpose}\t{text}\t{digest.hex()}\t{k0:08x}\t{k1:08x}\t{first64:016x}")
    if len(keys) != 33:
        raise RuntimeError("metadata key cardinality")
    Path(__file__).resolve().with_name("INDEPENDENT_33_KEYS.tsv").write_bytes(
        ("\n".join(rows) + "\n").encode("ascii")
    )


if __name__ == "__main__":
    main()
