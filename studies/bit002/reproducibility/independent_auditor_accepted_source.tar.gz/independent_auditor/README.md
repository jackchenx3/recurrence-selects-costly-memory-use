# Independent BRC2 auditor source

This is a source-only package for non-author review against the exact public
v0.4 protocol. No compilation, operator execution, fixture execution, cohort
creation, estimate generation, producer comparison, or scientific execution was
performed during construction. The only executed new helper was `audit_keys.py`,
which uses standard `hashlib` for the expressly permitted public seed metadata.

The three public inputs remain unchanged. `INPUTS.sha256` identifies them.
`SOURCE_INVENTORY.tsv` identifies the delivered files by path, bytes and SHA-256;
its own hash must be recorded separately when this package is frozen.
`SOURCE_CONSTRUCTION_REPORT.txt` records the construction checks and open gates.

## Files

- `src/base.hpp`: explicit byte operations, independent SHA-256, canonical text
  primitives, regular-file reads and atomic writes, and frozen tier table.
- `src/operator.hpp`: independent Philox, validated coordinates, tape access,
  exact Lemire/Plackett-Luce selection, four candidate families, mutation/cache
  transitions, arm serialization, history chain and full-history replay.
- `src/inference.hpp`: arbitrary-precision normalized fractions, six intervals,
  all labels/patterns/summaries and the canonical results renderer.
- `src/audit.hpp`, `src/audit_main.cpp`: staged A-L audit, canonical INVALID form,
  descriptive rows, audit report, separate K timer and timing-only discard.
- `src/fixture.hpp`, `src/fix_main.cpp`: generic FIXIN and FIXOUT readers/writers
  for all five kinds; injected versus Philox rules; conditional checks.
- `src/selfcheck.hpp`, `src/corruption.hpp`, `src/harness_main.cpp`: future public
  KAT/key/coordinate/mapping/sharing checks, sanitized bundle processing,
  conditional demonstration, frozen-output comparison and corruption suite.
- `audit_keys.py`, `INDEPENDENT_33_KEYS.tsv`: public key metadata recipe and its
  independently computed table. No producer or legacy keys were read.

## Build recipe, after independent source GO and the applicable gates

Target: Linux, GNU g++ 8.5, C++17, GNU unsigned 128-bit multiply, POSIX file I/O,
Boost.Multiprecision `cpp_int` headers, and GCC 8's `libstdc++fs`.
No library binaries other than the normal C++ runtime/filesystem are required.
Dependency availability and all compiler diagnostics remain unverified until G2.

```
make CXX=g++
sha256sum bin/brc2_audit bin/brc2_fix bin/brc2_fixture_harness
```

The Makefile uses `-std=c++17 -O2 -Wall -Wextra -Wpedantic -fno-fast-math`
and `-lstdc++fs`. It does not run tests automatically. The scientific operator
and rational inference use integers exclusively. Floating point appears only in
monotonic wall-clock timing and its rendering. Scientific fractions use
arbitrary-precision cross-products, not bounded 128-bit fractions.

## Auditor interface

```
brc2_audit --tier <production-r1|fixture-r1|benchmark-r1> --data <dir> --out <file> [--timing-only]
```

The output parent must already exist and must be outside the data directory.
`AUDIT_REPORT.txt` is placed beside the requested results file. Results/report
writes use an exclusive temporary, fsync, rename and directory fsync; results
have mode 0400. The program reads no scheduler state. Exit 0 means VALID,
1 means the staged INVALID form, and 2 means usage/environment failure.
An unexpected output-commit failure exits 3 and preserves evidence; the report
is committed before the results, so it cannot fail after a successful results
commit. A directory-fsync failure during a results commit also exits 3.
Only status, wall seconds and separate K seconds are printed.

Timing-only still runs every applicable check, exact inference and classification,
renders both files in memory and computes their SHA-256 before discarding them.
It creates no results/report files and prints no hash, estimate or aggregate.

A checks the exact inventory, canonical manifest and hashes, chunk headers and
complete block IDs. Trace size/headers are derived from the tier's checkpoint
key, independent of potentially corrupted record checkpoint fields; those fields
are tested in C/D. B scans every record. Only after A and B pass do C-K run on
every applicable block, collecting all failing letters; only a completely
successful C-K stage enters L. Global file/cohort failures have no invented block
ID (`failing_blocks=0 first_ids=NONE` unless block failures also exist).

All six arms execute separately, including coincident cases. Payload identity
uses exactly bytes [8,280). K replays exactly 64 complete histories in production
and benchmark, and 16 in fixture. Production blocks 64 onward receive conditional
checkpoint validation but no population-history provenance replay. This limit is
preserved. No count, threshold, endpoint or inferential family is configurable.

## Generic fixture commands, only after the required reviews/freezes

The following are recipes, not actions taken during this source delivery.
`<cond-id>` is the ID of the COND_FORGE input in the eventually released,
sanitized public bundle; this package invents no such input or ID value.

```
brc2_fixture_harness public-checks --kat public_reference/Random123_kat_vectors.txt --keys INDEPENDENT_33_KEYS.tsv
brc2_fix --in FIXIN_BUNDLE/FIXIN_<id>.txt --out <own-output-file>
brc2_fixture_harness fixout --bundle FIXIN_BUNDLE --out-dir <new-own-FIXOUT-dir> --cond-forge-id <cond-id>
```

The single-file command derives the fixture ID from the input filename. The
bundle command verifies INDEX hashes and the exact public input inventory,
processes every item, validates its own FIXOUT grammar, and checks canonical
FIXIN round trips for valid typed inputs. Invalid inputs yield only the specified
ERROR body. No hard-coded fixture populations or expected outcomes exist.
LEMIRE exhaustion and the 256-retry cap are distinct. CHECKPOINT injection
requires `r_t` and every tape field. PHILOX forbids injected fields and derives
its tag. HISTORY accepts only its enumerated prefixed tape fields and its own
copy coin; the first two coins are ignored by the HALF law. Constructed block
identities are restricted to fixture blocks 0..15. A fixture-only RNG context
allows a PHILOX CHECKPOINT's stated update to be its focal-key update; it cannot
alter the production or benchmark checkpoint rule.

The conditional receipt contains exactly C_PAYLOAD, E, F_INJECTED, G, H, I and
NOT_APPLICABLE=A,B,D,J,K,L. It never emits cohort-style A-L acceptance for
COND_FORGE. Missing or invalid input, or any failed conditional check, fails
that fixture command.

Freeze the auditor source, binary and own FIXOUT at G4a **before** accessing any
producer output. Only afterward may the separate comparison/corruption recipes
be used under their applicable authority:

```
brc2_fixture_harness compare --bundle FIXIN_BUNDLE --own-dir <frozen-own-dir> --other-dir <producer-FIXOUT-dir> --cond-forge-id <cond-id>
brc2_audit --tier fixture-r1 --data <producer-fixture-data> --out <audit-dir>/RESULTS_AUDITOR.txt
brc2_fixture_harness compare-results --own <auditor-results> --other <analyzer-results>
brc2_fixture_harness corrupt --data <producer-fixture-data> --scratch <new-scratch-dir>
```

Comparison reads frozen files without regenerating own outputs. Results comparison
hashes bytes without parsing or displaying contents. The corruption suite first
requires baseline A-L success, then uses its own scratch copies. It flips a byte
in every declared record region for all 16 blocks, exercises raw/truncated/
duplicate/swapped/missing/extra/temp/manifest cases, rehashes semantic forgeries,
and separately requires A-J PASS and K FAIL for FORGE_CACHE in block 3. It
preserves a failing case and emits only check letters and engineering status.
If block 3 has no eligible M slot, the specified FORGE_CACHE test fails rather
than changing the designated block. The scratch directory must not already
exist; it is outside the original data inventory.

## Key recipe and remaining gates

The already-performed metadata-only command is:

```
python3 audit_keys.py
```

For each of the 11 exact purpose strings in protocol order and each of
`production-r1`, `fixture-r1`, `benchmark-r1`, the ASCII string is
`PHASE3-BIT-RETRIEVAL-CAUSALITY-002|<tier>|<purpose>`, without a terminator.
The table stores that entire string, its full SHA-256 digest, numeric k0 and k1
from digest bytes 0:4 and 4:8 read little-endian, and the numeric first-64-bit key
from bytes 0:8 read little-endian. Hex columns are lowercase, fixed-width numeric
representations. The helper checked all 33 keys for pairwise distinctness.

The other author's independently computed table and the sanitized legacy string
manifest have not been supplied or compared. G1F bundle review/freeze and key
agreement/disjointness remain open. Non-author source review must GO before
compilation or fixtures. G2, own fixtures/FIXOUT and G4a freeze, G4 comparisons,
benchmark qualification, readiness, one scientific submission, execution
acceptance and publication all remain unexecuted. These recipes waive no gate
and authorize no submission or post-production rerun. Remaining integrated
corrections: zero.
