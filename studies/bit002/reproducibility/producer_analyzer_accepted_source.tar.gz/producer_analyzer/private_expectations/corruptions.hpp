#pragma once
#include "harness_support.hpp"
namespace brc { namespace fixture {
inline void corruption_suite(const fs::path&baseline,const fs::path&work){auto t=tier("fixture-r1");auto d=load(t,baseline);fs::create_directory(work/"corruptions");unsigned serial=0;auto fresh=[&](const std::string&name){auto p=work/"corruptions"/(std::to_string(serial++)+"_"+name);clone(baseline,p);return p;};
 // A/B: each byte region is changed; transport hashes are repaired but the
 // record hash is deliberately left stale. ID and t affect A; B detects the rest.
 std::vector<u32>offsets={0,4,6,8,12,13,14,16,20,24,28,32,36,40,41,42,43,44,52,56,60,64,68,72,104,232,360,368,384,2040,2042,2046,2048,2052,2056};
 for(u32 off:offsets){auto p=fresh("byte_region");modify_record(p,d,3,[&](Record&r){r[off]^=1;},false);auto a=analyze(t,p);expect_letters(a,off==8||off==14?"A":"B");}
 for(auto kind:{"truncation","duplicate","swapped","wrong_length","missing_chunk","extra_file","leftover_tmp","manifest_tamper"}){auto p=fresh(kind);std::string k=kind;
  if(k=="truncation"){auto b=readfile(p/"chunk_00.bin");b.pop_back();overwrite(p/"chunk_00.bin",b);}
  else if(k=="duplicate"||k=="swapped"){auto b=readfile(p/"chunk_00.bin");if(k=="duplicate")std::copy(d.records[0].begin(),d.records[0].end(),b.begin()+64+2088);else {std::copy(d.records[0].begin(),d.records[0].end(),b.begin()+64+2088);std::copy(d.records[1].begin(),d.records[1].end(),b.begin()+64);}overwrite(p/"chunk_00.bin",b);rehash(p,d);}
  else if(k=="wrong_length")modify_record(p,d,3,[](Record&r){put(r.data()+6,2087,2);});
  else if(k=="missing_chunk")fs::remove(p/"chunk_00.bin");
  else if(k=="extra_file")atomictext(p/"extra.txt","X\n");
  else if(k=="leftover_tmp")atomictext(p/".tmp.interrupted","X\n");
  else if(k=="manifest_tamper"){auto b=readfile(p/"MANIFEST.txt");b[0]^=1;overwrite(p/"MANIFEST.txt",b);}
  auto a=analyze(t,p);expect_letters(a,k=="wrong_length"?"B":"A");
 }
 auto forged=[&](const std::string&name,const std::string&letters,const std::function<void(Record&)>&edit){auto p=fresh(name);modify_record(p,d,3,edit);auto a=analyze(t,p);require(a.bad[0].empty()&&a.bad[1].empty(),"forged corruption must pass A/B");expect_letters(a,letters);};
 forged("survivor_mismatch","FG",[](Record&r){auto&p=r[360+24+1];p=u8((p+1)%33);});
 forged("survivor_genotype","F",[](Record&r){r[360+24+4]^=1;});
 forged("candidate_index","CF",[](Record&r){r[360+24]=128;});
 forged("numerator","G",[](Record&r){r[2040]=r[2040]==32?31:u8(r[2040]+1);});
 forged("focal_slot","D",[](Record&r){r[42]=u8((r[42]+1)%32);});
 forged("focal_key","D",[](Record&r){r[44]^=1;});
 forged("nonzero_key_H0","CD",[](Record&r){put(r.data()+36,0,4);r[40]=0;r[41]=0;r[42]=255;put(r.data()+44,1,8);});
 forged("invalid_nonzero_cache","C",[](Record&r){u32 valid=u32(get(r.data()+56,4));put(r.data()+56,valid&~u32(1),4);put(r.data()+232,1,4);});
 forged("checkpoint_word","D",[](Record&r){r[16]^=64;});
 {auto p=fresh("checkpoint_t");u32 old=u32(get(d.records[3].data()+14,2)),now=old==193?194:193;modify_record(p,d,3,[&](Record&r){put(r.data()+14,now,2);});reshape_trace(p,d,3,now);auto a=analyze(t,p);require(a.bad[0].empty()&&a.bad[1].empty(),"forged t must pass A/B");expect_letters(a,"D");}
 forged("start_code","C",[](Record&r){r[12]^=1;});
 forged("R_t","D",[](Record&r){r[13]^=1;r[43]=u8(1-r[13]);for(u32 a=0;a<6;++a)r[360+280*a+3]=u8(a==(r[13]?0:3));put(r.data()+32,get(r.data()+(r[13]?20:28),4),4);});
 forged("switched_mask","C",[](Record&r){r[360+280+4]^=1;});
 forged("swapped_arms","C",[](Record&r){for(u32 j=0;j<280;++j)std::swap(r[360+j],r[640+j]);});
 forged("block_query_count","CJ",[](Record&r){put(r.data()+64,767,4);});
 forged("arm_query_count","CJ",[](Record&r){put(r.data()+360+8,127,2);});
 // A syntactically well-formed new state is conditionally replayed, while the
 // original digest/trace evidence is retained. K alone must reject it.
 {auto p=fresh("FORGE_CACHE");u32 E=u32(get(d.records[3].data()+36,4));require(E!=0,"FORGE_CACHE fixture block 3 has no eligible parent; fixture fails");u32 slot=0;while(((E>>slot)&1)==0)++slot;
  modify_record(p,d,3,[&](Record&r){auto s=prestate(r);s.cache[slot]^=1;put(r.data()+232+4*slot,s.cache[slot],4);Rng g(t,3);u32 u=u32(get(r.data()+14,2));auto tape=g.tape(u);g.focal_keys(tape,u);auto cp=evaluate(s,u32(get(r.data()+20,4)),u32(get(r.data()+28,4)),r[13],tape);storecheckpoint(r,cp);});auto a=analyze(t,p);require(failedletters(a)=="K","FORGE_CACHE must fail K alone");}
 atomictext(work/"CORRUPTION_RECEIPT.txt","BRC2-CORRUPTIONS-V1\nraw_regions=35\nraw_and_structural=PASS\nforged_semantic=PASS\nFORGE_CACHE=A-J_PASS_K_FAIL\n",0400);
}
inline void arithmetic_checks(const fs::path&bundle){
 auto z=infer({{0,0,0,0,0,0}},42000);for(unsigned x=0;x<6;++x)require(z.means[x]==Rat()&&z.iv[x].lo==Rat()-halfwidth(x)&&z.iv[x].hi==halfwidth(x)&&z.labels[x]==NG,"zero-cohort exact arithmetic");auto r=infer({{1344000,1344000,0,0,0,0}},42000);require(r.means[0]==Rat(1)&&r.iv[0].hi==Rat(1)&&r.iv[0].lo==Rat(1)-halfwidth(0),"clipping at 1");require(Rat(Big("18446744073709551616"),Big("18446744073709551617"))<Rat(1),"arbitrary precision comparison");require((Rat(Big("18446744073709551616"),3)+Rat(1,3)).str()=="18446744073709551617/3","unbounded numerator");
 Big wide=Big(1)<<200;require(Rat(wide,wide+1)<Rat(wide+1,wide+2),"400-bit rational cross-products");
 const char*expected[25]={"CONCORDANT_MATERIAL_POSITIVE","OFFSETTING_MATERIAL","RECURRENT_ONLY_MATERIAL_POSITIVE","ONE_MATERIAL_OTHER_SIGN_ONLY_SAME","ONE_MATERIAL_OTHER_SIGN_ONLY_OPPOSING","OFFSETTING_MATERIAL","CONCORDANT_MATERIAL_NEGATIVE","RECURRENT_ONLY_MATERIAL_NEGATIVE","ONE_MATERIAL_OTHER_SIGN_ONLY_OPPOSING","ONE_MATERIAL_OTHER_SIGN_ONLY_SAME","INNOVATION_ONLY_MATERIAL_POSITIVE","INNOVATION_ONLY_MATERIAL_NEGATIVE","BOTH_NEGLIGIBLE","NONMATERIAL_OTHER","NONMATERIAL_OTHER","ONE_MATERIAL_OTHER_SIGN_ONLY_SAME","ONE_MATERIAL_OTHER_SIGN_ONLY_OPPOSING","NONMATERIAL_OTHER","NONMATERIAL_OTHER","OPPOSING_SIGNS_NONMATERIAL","ONE_MATERIAL_OTHER_SIGN_ONLY_OPPOSING","ONE_MATERIAL_OTHER_SIGN_ONLY_SAME","NONMATERIAL_OTHER","OPPOSING_SIGNS_NONMATERIAL","NONMATERIAL_OTHER"};
 const char*codes="MNGPQ";for(unsigned a=0;a<5;++a)for(unsigned b=0;b<5;++b){std::string id=std::string("CLASS_PAIR_")+codes[a]+codes[b];auto out=fixout(readtext(bundle/("FIXIN_"+id+".txt")));require(out.find(std::string("PATTERN L ")+expected[5*a+b]+"\n")!=std::string::npos,"all pattern rules");std::string token;if((a==0&&b==1)||(a==1&&b==0))token="S1_";else if(a==1||b==1)token="S2_";else if(a==0||b==0)token="S3_";else if(a==2&&b==2)token="S4_";else token="S5_";require(out.find("SUMMARY "+token)!=std::string::npos,"all summary rules");}
 auto out=fixout(readtext(bundle/"FIXIN_CLASS_DELTA_EQUAL.txt"));require(out.find("LABEL L_rec POSITIVE_MAGNITUDE_UNRESOLVED\n")!=std::string::npos&&out.find("LABEL F_rec POSITIVE_MAGNITUDE_UNRESOLVED\n")!=std::string::npos,"delta equality is strict");for(auto id:{"CLASS_NEG_DELTA_EQUAL","CLASS_NEG_MARGIN_EQUAL"}){out=fixout(readtext(bundle/("FIXIN_"+std::string(id)+".txt")));require(out.find("LABEL L_rec NEGATIVE_MAGNITUDE_UNRESOLVED\n")!=std::string::npos,"negative boundary strictness");}out=fixout(readtext(bundle/"FIXIN_CLASS_FALLTHROUGH.txt"));require(out.find("LABEL L_rec FALLTHROUGH\n")!=std::string::npos&&out.find("SUMMARY S0_INVALID\n")!=std::string::npos&&out.find("DERIVED")==std::string::npos,"fallthrough invalid form");
}
}}
