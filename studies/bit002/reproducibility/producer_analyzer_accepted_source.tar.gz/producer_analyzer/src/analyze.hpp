#pragma once
#include "dataset.hpp"
#include "inference.hpp"
namespace brc {
struct Audit {std::array<std::set<u32>,12>bad;std::array<bool,12>evaluated{};std::string result;u64 k_ns=0;bool valid=false;};
inline bool integrity(const Record&r){auto h=sha(r.data(),2056);return std::memcmp(r.data(),"BRC2",4)==0&&get(r.data()+4,2)==2&&get(r.data()+6,2)==2088&&std::equal(h.begin(),h.end(),r.begin()+2056);}
inline bool payload_equal(const Bytes&a,const Bytes&b){return std::equal(a.begin()+8,a.end(),b.begin()+8);}
inline void ranges(const Record&r,const Tier&t,u32 b){
 u32 rt=r[13],u=u32(get(r.data()+14,2)),w=u32(get(r.data()+16,4)),E=u32(get(r.data()+36,4)),e=r[40],f=r[42];
 require(r[12]==(b&1)&&rt<=1&&r[43]==1-rt&&u==checkpoint(t,w),"C header");require(e==pop(E)&&r[41]==u32(e>0),"C eligibility");if(e){require(f<32&&((E>>f)&1),"C focal membership");}else require(f==255&&get(r.data()+44,8)==~u64(0),"C focal sentinel");
 require(get(r.data()+60,4)==128*(u-1)&&get(r.data()+64,4)==768&&get(r.data()+2048,4)==128*(u+5)&&get(r.data()+2052,4)==0,"C accounting");auto s=prestate(r);for(u32 i=0;i<32;++i)require(((s.valid>>i)&1)||s.cache[i]==0,"C invalid cache");
 for(u32 a=0;a<6;++a){auto p=r.data()+360+280*a;u32 q=a%3==0?0:a%3==1?E:(f<32?u32(1)<<f:0);require(p[0]==a&&p[1]==a/3&&p[2]==a%3&&p[3]==u32(a==(rt?0:3))&&get(p+4,4)==q,"C arm metadata");require(get(p+8,2)==128&&get(p+10,2)<=8160&&p[12]<=32&&p[13]<=4&&get(p+14,2)<=1024&&get(p+20,4)<=4096,"C arm ranges");u32 pm=0;std::set<u32>seen;
  for(u32 k=0;k<32;++k){auto v=p+24+8*k;require(v[0]<128&&seen.insert(v[0]).second&&v[1]<=32&&v[2]<=1,"C survivor");pm|=u32(v[2])<<k;}require(get(p+16,4)==pm,"C post mask");}
 auto ns=recordnums(r);for(unsigned x=0;x<6;++x){i64 z=x<2?32:x<4?1024:4;require(ns[x]>=-z&&ns[x]<=z,"C numerator");}
}
inline void keyfields(const Record&r,const Rng&g){u32 w=g.word(TIME,0),u=checkpoint(g.t,w),rt=g.word(COPY,u)&1;require(get(r.data()+16,4)==w&&get(r.data()+14,2)==u&&r[13]==rt&&get(r.data()+28,4)==g.word(INNOV,u)&&get(r.data()+32,4)==(rt?get(r.data()+20,4):g.word(INNOV,u)),"D target fields");u32 E=u32(get(r.data()+36,4));u8 f=255;u64 key=~u64(0);for(u32 i=0;i<32;++i){u64 k=g.wide(FOCAL,u,i);if((E&(u32(1)<<i))&&(f==255||k<key)){key=k;f=u8(i);}}require(r[42]==f&&get(r.data()+44,8)==key,"D focal");}
inline std::array<i64,6> counts_from_survivors(const std::array<Bytes,6>&arms,u32 E,u32 f,u32 rec,u32 inn,const std::array<Bytes,6>&replay){
 std::array<Bytes,6>copy=arms;for(u32 a=0;a<6;++a){u32 de=0,df=0,ac=0,retry=0;for(u32 k=0;k<32;++k){auto p=arms[a].data()+24+8*k;require(p[0]<128&&p[1]<=32,"G survivor range");u32 parent=p[0]%32;de+=(E>>parent)&1;df+=parent==f;ac+=32-p[1];retry+=p[3];require(pop(u32(get(p+4,4))^(a<3?rec:inn))==p[1],"G mismatch");}require(arms[a][12]==de&&arms[a][13]==df&&get(arms[a].data()+14,2)==ac&&get(arms[a].data()+10,2)==retry,"G counts");require(replay[a][12]==de&&replay[a][13]==df&&get(replay[a].data()+14,2)==ac,"G replay counts");copy[a][12]=u8(de);copy[a][13]=u8(df);put(copy[a].data()+14,ac,2);}return numerators(copy);
}
inline void bounds(const std::array<i64,6>&n,u32 e){require(e<=32,"H e");i64 z=std::min({u32(32),4*e,128-4*e});require(std::abs(n[0])<=z&&std::abs(n[1])<=z&&std::abs(n[2])<=1024&&std::abs(n[3])<=1024&&std::abs(n[4])<=4&&std::abs(n[5])<=4,"H bounds");}
inline void identities(const std::array<Bytes,6>&a,const std::array<i64,6>&n,u32 e){if(e==0){require(payload_equal(a[0],a[1])&&payload_equal(a[0],a[2])&&payload_equal(a[3],a[4])&&payload_equal(a[3],a[5]),"I H0");for(auto v:n)require(v==0,"I H0 numerators");}if(e==1)require(payload_equal(a[1],a[2])&&payload_equal(a[4],a[5]),"I e1");}
inline Audit analyze(const Tier&t,const fs::path&root){
 Audit audit;std::string mh="NONE";try{mh=hex(sha(readfile(root/"MANIFEST.txt")));}catch(...){}
 Data d;auto failresult=[&]{std::vector<std::string>v;for(unsigned i=0;i<12;++i)if(!audit.bad[i].empty())v.push_back(std::string(1,char('A'+i)));audit.result=invalidresults(t,mh,joined(v));};
 audit.evaluated[0]=true;try{d=load(t,root);mh=d.manifest_digest;}catch(...){audit.bad[0].insert(0);failresult();return audit;}
 audit.evaluated[1]=true;for(u32 b=0;b<t.n;++b)if(!integrity(d.records[b]))audit.bad[1].insert(b);if(!audit.bad[1].empty()){failresult();return audit;}
 for(unsigned i=2;i<=10;++i)audit.evaluated[i]=true;u64 total=0;Stats stats;
 for(u32 b=0;b<t.n;++b){const auto&r=d.records[b];auto check=[&](unsigned i,const std::function<void()>&f){try{f();}catch(...){audit.bad[i].insert(b);}};Rng g(t,b);u32 E=u32(get(r.data()+36,4)),e=r[40],u=u32(get(r.data()+14,2));auto arms=recordarms(r);auto nums=recordnums(r);Checkpoint replay;bool replayed=false;
  check(2,[&]{ranges(r,t,b);});check(3,[&]{keyfields(r,g);});
  check(4,[&]{auto s=prestate(r);require(s.valid==s.policy&&E==(s.policy&s.valid),"E invariants");});
  check(5,[&]{auto tape=g.tape(u);g.focal_keys(tape,u);replay=evaluate(prestate(r),u32(get(r.data()+20,4)),u32(get(r.data()+28,4)),r[13],tape);replayed=true;for(unsigned a=0;a<6;++a)require(arms[a]==replay.arms[a],"F replay");});
  check(6,[&]{require(replayed,"G replay available");auto computed=counts_from_survivors(arms,E,r[42],u32(get(r.data()+20,4)),u32(get(r.data()+28,4)),replay.arms);require(computed==nums&&computed==replay.nums,"G numerator agreement");});
  check(7,[&]{bounds(nums,e);});check(8,[&]{identities(arms,nums,e);});
  check(9,[&]{require(u>=193&&u<=256&&get(r.data()+60,4)==128*(u-1)&&get(r.data()+64,4)==768&&get(r.data()+2048,4)==128*(u+5),"J block");for(auto&a:arms)require(get(a.data()+8,2)==128,"J arm");});total+=get(r.data()+2048,4);
  if(b<t.trace){auto start=std::chrono::steady_clock::now();check(10,[&]{u32 actual=checkpoint(t,g.word(TIME,0));auto h=history(g,actual,true);require(statebytes(h.s)==statebytes(prestate(r))&&get(r.data()+20,4)==h.prev2&&get(r.data()+24,4)==h.prev1&&get(r.data()+68,4)==h.retries&&std::equal(h.digest.begin(),h.digest.end(),r.begin()+72)&&h.chain==d.trace[b],"K history");});audit.k_ns+=u64(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count());}
 }
 u64 expected=0;for(u32 b=0;b<t.n;++b){Rng g(t,b);expected+=128*(checkpoint(t,g.word(TIME,0))+5);}if(total!=expected||total!=d.queries||(t.benchmark&&total!=34209792))audit.bad[9].insert(0);
 for(unsigned i=2;i<=10;++i)if(!audit.bad[i].empty()){failresult();return audit;}
 audit.evaluated[11]=true;try{for(u32 b=0;b<t.n;++b){auto&r=d.records[b];unsigned st=b&1;auto nums=recordnums(r);for(unsigned x=0;x<6;++x){stats.sums[x]+=nums[x];stats.starts[st][x]+=nums[x];}++stats.ehist[st][r[40]];stats.h[st]+=r[41];stats.r1[st]+=r[13];unsigned factual=r[13]?0:3;stats.factual[st]+=get(r.data()+360+280*factual+14,2);}audit.result=validresults(t,mh,stats);audit.valid=true;}catch(...){audit.bad[11].insert(0);failresult();}return audit;
}
}
