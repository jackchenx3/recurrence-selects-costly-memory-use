#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include <utility>
#include "vendor/sha256.hpp"
#include "vendor/philox.hpp"
namespace brc {
using u8=std::uint8_t; using u16=std::uint16_t; using u32=std::uint32_t; using u64=std::uint64_t;
using i64=std::int64_t; using Bytes=std::vector<u8>; using Digest=mm::Sha256Digest;
namespace fs=std::filesystem;
inline constexpr char STUDY[]="PHASE3-BIT-RETRIEVAL-CAUSALITY-002";
inline constexpr char PROTOCOL[]="71ccc1d065fa4868c30f96588ec34312bdc435e1047214c60b1f5643846c7daa";
struct Error:std::runtime_error { using std::runtime_error::runtime_error; };
inline void require(bool b,const std::string& s){if(!b)throw Error(s);}
inline u32 pop(u32 v){return u32(__builtin_popcount(v));}
inline u64 get(const u8* p,unsigned n){u64 v=0; for(unsigned i=0;i<n;++i)v|=u64(p[i])<<(8*i);return v;}
inline void put(u8* p,u64 v,unsigned n){for(unsigned i=0;i<n;++i)p[i]=u8(v>>(8*i));}
inline void append(Bytes& b,u64 v,unsigned n){auto o=b.size();b.resize(o+n);put(b.data()+o,v,n);}
inline void append(Bytes& b,const Digest& d){b.insert(b.end(),d.begin(),d.end());}
inline void literal(Bytes& b,const std::string& s){b.insert(b.end(),s.begin(),s.end());}
inline Digest sha(const void* p,std::size_t n){return mm::sha256_bytes(p,n);}
inline Digest sha(const Bytes& b){return sha(b.data(),b.size());}
inline Digest sha(const std::string& b){return sha(b.data(),b.size());}
inline std::string hex(const Digest& d){return mm::to_hex(d);}
inline std::string hex(const Bytes& b){return mm::to_hex(b.data(),b.size());}
inline std::string hx(u64 v,unsigned n){std::ostringstream o;o<<std::hex<<std::setfill('0')<<std::setw(n)<<v;return o.str();}
inline bool ishex(const std::string& s,std::size_t n){return s.size()==n && s.find_first_not_of("0123456789abcdef")==std::string::npos;}
inline Bytes unhex(const std::string& s){require(s.size()%2==0&&ishex(s,s.size()),"hex");Bytes b(s.size()/2);for(std::size_t i=0;i<b.size();++i)b[i]=u8(std::stoul(s.substr(i*2,2),nullptr,16));return b;}
inline std::vector<std::string> split(const std::string& s,char c){std::vector<std::string> v;std::size_t p=0;for(;;){auto q=s.find(c,p);v.push_back(s.substr(p,q==std::string::npos?q:q-p));if(q==std::string::npos)return v;p=q+1;}}
inline u64 decimal(const std::string& s,u64 max){require(!s.empty()&&(s=="0"||s[0]!='0'),"decimal");u64 v=0;for(char c:s){require(c>='0'&&c<='9',"decimal");u64 d=u64(c-'0');require(v<=max/10&&(v<max/10||d<=max%10),"decimal range");v=v*10+d;}return v;}
struct Tier {std::string name;u32 code,n,trace;bool benchmark;u32 chunks()const{return (n+999)/1000;}};
inline Tier tier(const std::string& s){if(s=="production-r1")return{s,1,42000,64,false};if(s=="benchmark-r1")return{s,3,1024,64,true};if(s=="fixture-r1")return{s,2,16,16,false};throw Error("tier");}
inline u32 checkpoint(const Tier& t,u32 w){return t.benchmark?256:193+(w&63);}
inline std::string chunkname(u32 k){return "chunk_"+std::string(k<10?"0":"")+std::to_string(k)+".bin";}
inline i64 signed_field(const u8* p,unsigned n){u64 v=get(p,n),sign=u64(1)<<(8*n-1);return (v&sign)?i64(v)-i64(u64(1)<<(8*n)):i64(v);}
inline std::map<std::string,std::string> cli(int argc,char**argv,const std::set<std::string>& value,const std::set<std::string>& flags={}){
 std::map<std::string,std::string> m;for(int i=1;i<argc;++i){std::string k=argv[i];require(!m.count(k),"duplicate option");if(flags.count(k))m[k]="1";else {require(value.count(k)&&i+1<argc,"unknown or missing option");m[k]=argv[++i];}}for(auto& k:value)require(m.count(k),"required option");return m;
}
}
