#pragma once
#include "base.hpp"
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
namespace brc {
inline Bytes readfile(const fs::path&p,u64 cap=u64(1)<<30){
 struct stat st{};require(::lstat(p.c_str(),&st)==0&&S_ISREG(st.st_mode)&&u64(st.st_size)<=cap,"read regular file");
 int fd=::open(p.c_str(),O_RDONLY|O_NOFOLLOW);require(fd>=0,"open input");Bytes b(std::size_t(st.st_size));std::size_t off=0;
 while(off<b.size()){ssize_t n=::read(fd,b.data()+off,b.size()-off);if(n<0&&errno==EINTR)continue;if(n<=0){::close(fd);throw Error("short read");}off+=std::size_t(n);}u8 extra;ssize_t n=::read(fd,&extra,1);int c=::close(fd);require(n==0&&c==0,"input changed or close");return b;
}
inline std::string readtext(const fs::path&p,u64 cap=u64(1)<<20){auto b=readfile(p,cap);return std::string(b.begin(),b.end());}
inline void syncdir(const fs::path&p){int fd=::open(p.c_str(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW);require(fd>=0,"directory open");int s=::fsync(fd),c=::close(fd);require(s==0&&c==0,"directory fsync");}
// The hook is used only by the fixture harness's forked kill test, never by CLI.
inline void atomicfile(const fs::path&p,const Bytes&b,mode_t mode=0644,const std::function<void()>&mid_write={}){
 require(b.size()<=(u64(1)<<30),"output cap");require(!fs::exists(p)&&!fs::is_symlink(fs::symlink_status(p)),"output exists");
 fs::path tmp=p.parent_path()/(".tmp."+p.filename().string());int fd=::open(tmp.c_str(),O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0600);require(fd>=0,"temporary open");
 std::size_t off=0;while(off<b.size()){ssize_t n=::write(fd,b.data()+off,std::min(std::size_t(4096),b.size()-off));if(n<0&&errno==EINTR)continue;if(n<=0){::close(fd);throw Error("write");}off+=std::size_t(n);if(mid_write&&off==std::size_t(n))mid_write();}
 int m=::fchmod(fd,mode),s=::fsync(fd),c=::close(fd);require(m==0&&s==0&&c==0,"file fsync");require(::rename(tmp.c_str(),p.c_str())==0,"rename");syncdir(p.parent_path());
}
inline void atomictext(const fs::path&p,const std::string&s,mode_t mode=0644){atomicfile(p,Bytes(s.begin(),s.end()),mode);}
inline void emptydir(const fs::path&p){if(fs::exists(p)){require(fs::is_directory(fs::symlink_status(p))&&fs::is_empty(p),"output must be absent or empty directory");}else{require(!fs::is_symlink(fs::symlink_status(p)),"symlink output");require(fs::create_directories(p),"create output");}}
// /proc/self/exe is itself a symlink; use its resolved path before regular-file reading.
inline Digest executableid(){return sha(readfile(fs::read_symlink("/proc/self/exe")));}
inline std::vector<std::string> lines(const std::string&s){require(!s.empty()&&s.back()=='\n'&&s.find('\r')==std::string::npos,"LF text");for(unsigned char c:s)require(c==10||(c>=32&&c<=126),"ASCII text");auto v=split(s,'\n');v.pop_back();for(auto&x:v)require(!x.empty()&&x.front()!=' '&&x.back()!=' ',"text spacing");return v;}
}
