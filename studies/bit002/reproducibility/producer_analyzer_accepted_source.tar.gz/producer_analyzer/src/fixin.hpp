#pragma once
#include "analyze.hpp"
namespace brc {
struct InputError:Error{using Error::Error;};
inline void syntax(bool b){if(!b)throw InputError("INPUT_SYNTAX");}
inline void range(bool b){if(!b)throw InputError("INPUT_RANGE");}
struct Input {
 std::vector<std::string>v;std::size_t at=0;
 explicit Input(const std::string&s){try{v=lines(s);}catch(...){throw InputError("INPUT_SYNTAX");}}
 std::string raw(){syntax(at<v.size());return v[at++];}
 std::string field(const std::string&key){auto s=raw();syntax(s.substr(0,key.size()+1)==key+"=");return s.substr(key.size()+1);}
 void done(){syntax(at==v.size());}
};
inline u64 fi_dec(const std::string&s,u64 bound){syntax(!s.empty()&&(s=="0"||s.front()!='0')&&s.find_first_not_of("0123456789")==std::string::npos);try{return decimal(s,bound);}catch(...){throw InputError("INPUT_RANGE");}}
inline u64 fi_hex(const std::string&s,unsigned n){syntax(ishex(s,n));return std::stoull(s,nullptr,16);}
inline std::vector<u64> fi_list(const std::string&s,unsigned n,std::size_t min,std::size_t max){auto v=split(s,',');range(v.size()>=min&&v.size()<=max);std::vector<u64>o;for(auto&x:v)o.push_back(fi_hex(x,n));return o;}
inline i64 fi_int(const std::string&s,i64 bound){Big b;try{b=bigint(s);}catch(...){throw InputError("INPUT_SYNTAX");}range(b>=-bound&&b<=bound);return b.convert_to<i64>();}
inline std::array<i64,6> fi_nums(const std::string&s){auto v=split(s,',');range(v.size()==6);std::array<i64,6>n{};for(unsigned x=0;x<6;++x)n[x]=fi_int(v[x],x<2?32:x<4?1024:4);return n;}
inline void fi_state(const State&s,u32 u){range((s.valid&~s.policy)==0);if(u==1)range(s.valid==0);for(unsigned i=0;i<32;++i)range(((s.valid>>i)&1)||s.cache[i]==0);}
inline Tape injected(Input&in,const std::string&prefix=""){
 Tape d;auto a=fi_list(in.field(prefix+"fresh"),8,32,32),b=fi_list(in.field(prefix+"scout"),8,32,32),c=fi_list(in.field(prefix+"local"),8,32,32),k=fi_list(in.field(prefix+"donor"),16,96,96);for(unsigned i=0;i<32;++i){d.fresh[i]=u32(a[i]);d.scout[i]=u32(b[i]);d.local[i]=u32(c[i]);}std::copy(k.begin(),k.end(),d.donor.begin());
 std::array<std::vector<u64>,32>seq;for(unsigned i=0;i<32;++i)seq[i]=fi_list(in.field(prefix+"survival_"+(i<10?std::string("0"):std::string())+std::to_string(i)),16,1,256);d.flip=u32(fi_hex(in.field(prefix+"policy_flip"),8));auto f=fi_list(in.field(prefix+"focal"),16,32,32);std::copy(f.begin(),f.end(),d.focal.begin());d.survival=[seq](u32 draw,u32 retry){require(draw<32,"draw");if(retry>=seq[draw].size())throw DrawError("DRAW_EXHAUSTED");return seq[draw][retry];};return d;
}
struct CheckInput {State s;u32 u=0,rt=0,rec=0,inn=0;Tape tape;};
inline CheckInput checkpoint_input(Input&in){
 CheckInput c;auto mode=in.field("draws");syntax(mode=="INJECTED"||mode=="PHILOX");u32 block=0;if(mode=="PHILOX"){syntax(in.field("tier")=="fixture-r1");block=u32(fi_dec(in.field("block"),15));}c.u=u32(fi_dec(in.field("u"),256));range(c.u>=1);if(mode=="INJECTED")c.rt=u32(fi_dec(in.field("r_t"),1));auto x=fi_list(in.field("genotypes"),8,32,32),z=fi_list(in.field("caches"),8,32,32);for(unsigned i=0;i<32;++i){c.s.x[i]=u32(x[i]);c.s.cache[i]=u32(z[i]);}c.s.policy=u32(fi_hex(in.field("policy_mask"),8));c.s.valid=u32(fi_hex(in.field("cache_valid_mask"),8));c.rec=u32(fi_hex(in.field("t_rec"),8));c.inn=u32(fi_hex(in.field("t_inn"),8));fi_state(c.s,c.u);
 if(mode=="INJECTED")c.tape=injected(in);else{Rng g(tier("fixture-r1"),block);c.rt=g.word(COPY,c.u)&1;c.tape=g.tape(c.u);
  // Section 16.1 PHILOX CHECKPOINT alone supplies its own update (1..256).
  // The parser fixes fixture-r1/block 0..15; ordinary Rng validation stays strict.
  for(u32 i=0;i<32;++i){auto w=mm::philox4x32_10({{block,c.u,i,0}},g.keys[FOCAL]);c.tape.focal[i]=u64(w[0])|(u64(w[1])<<32);}
 }return c;
}
inline std::string checkpoint_body(const Checkpoint&c){std::string s="eligible_mask="+hx(c.eligible,8)+"\ne="+std::to_string(c.e)+"\nH="+std::to_string(c.e>0)+"\nfocal_slot="+hx(c.focal,2)+"\nfocal_key="+hx(c.key,16)+"\n";for(unsigned a=0;a<6;++a)s+="arm"+std::to_string(a)+"="+hex(c.arms[a])+"\n";s+="numerators=";for(unsigned x=0;x<6;++x){if(x)s+=",";s+=std::to_string(c.nums[x]);}return s+"\n";}
struct ConditionalChecks{std::array<bool,6>pass{};};
// Only the fixture-specific applicability contract: never a cohort A-L report.
inline ConditionalChecks conditional(const CheckInput&in,const Checkpoint&out){ConditionalChecks c;auto attempt=[&](unsigned i,const std::function<void()>&f){try{f();c.pass[i]=true;}catch(...){}};
 attempt(0,[&]{fi_state(in.s,in.u);require(out.eligible==(in.s.policy&in.s.valid)&&out.e==pop(out.eligible),"C_PAYLOAD eligibility");if(out.e)require(out.focal<32&&((out.eligible>>out.focal)&1),"C_PAYLOAD focal");else require(out.focal==255&&out.key==~u64(0),"C_PAYLOAD sentinel");for(unsigned a=0;a<6;++a){auto&v=out.arms[a];require(v.size()==280&&v[0]==a&&v[1]==a/3&&v[2]==a%3&&v[3]==u32(a==(in.rt?0:3)),"C_PAYLOAD metadata");u32 q=a%3==0?0:a%3==1?out.eligible:out.focal==255?0:u32(1)<<out.focal;require(get(v.data()+4,4)==q&&get(v.data()+8,2)==128&&get(v.data()+10,2)<=8160&&v[12]<=32&&v[13]<=4&&get(v.data()+14,2)<=1024&&get(v.data()+20,4)<=4096,"C_PAYLOAD ranges");std::set<u32>ids;u32 mask=0;for(unsigned k=0;k<32;++k){auto p=v.data()+24+8*k;require(p[0]<128&&ids.insert(p[0]).second&&p[1]<=32&&p[2]<=1,"C_PAYLOAD survivor");mask|=u32(p[2])<<k;}require(mask==get(v.data()+16,4),"C_PAYLOAD mask");}});
 attempt(1,[&]{require(in.s.valid==in.s.policy&&out.eligible==(in.s.policy&in.s.valid),"E");});
 attempt(2,[&]{auto r=evaluate(in.s,in.rec,in.inn,in.rt,in.tape);require(r.arms==out.arms&&r.focal==out.focal&&r.key==out.key,"F_INJECTED");});
 attempt(3,[&]{auto replay=evaluate(in.s,in.rec,in.inn,in.rt,in.tape);auto n=counts_from_survivors(out.arms,out.eligible,out.focal,in.rec,in.inn,replay.arms);require(n==out.nums&&n==replay.nums,"G");});attempt(4,[&]{bounds(out.nums,out.e);});attempt(5,[&]{identities(out.arms,out.nums,out.e);});return c;}
inline std::string fixout(const std::string&text){
 std::string id="UNKNOWN",kind,body;try{Input in(text);syntax(in.raw()=="BRC2-FIXIN-V1");id=in.field("fixture_id");syntax(id.size()>=1&&id.size()<=32&&id.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")==std::string::npos);kind=in.field("kind");
 if(kind=="LEMIRE"){u64 w=fi_hex(in.field("w"),16);range(w>=1&&w<=(u64(1)<<39));auto x=fi_list(in.field("x"),16,1,16);in.done();auto p=lemire(w,[&](u32 r){if(r>=x.size())throw DrawError("DRAW_EXHAUSTED");return x[r];});body="result="+std::to_string(p.retry)+","+hx(p.z,16)+"\n";}
 else if(kind=="CHECKPOINT"){auto c=checkpoint_input(in);in.done();body=checkpoint_body(evaluate(c.s,c.rec,c.inn,c.rt,c.tape));}
 else if(kind=="HISTORY"){
  syntax(in.field("draws")=="INJECTED");u32 b=u32(fi_dec(in.field("block_id"),15));auto start=in.field("start");syntax(start=="ALL_F"||start=="ALL_M");u32 n=u32(fi_dec(in.field("updates"),3));range(n>=1);auto x=fi_list(in.field("genotypes0"),8,32,32);State s;s.policy=start=="ALL_M"?~u32(0):0;for(unsigned i=0;i<32;++i)s.x[i]=u32(x[i]);std::array<Tape,3>tapes;std::array<u32,3>innov{},copy{};
  for(u32 u=1;u<=n;++u){std::string p="u"+std::to_string(u)+".";innov[u-1]=u32(fi_hex(in.field(p+"innov"),8));copy[u-1]=u32(fi_dec(in.field(p+"copy"),1));tapes[u-1]=injected(in,p);}in.done();Digest d=hist0(b,s);body="D_u0="+hex(d)+"\n";u32 prev2=0,prev1=0;
  for(u32 u=1;u<=n;++u){u32 target=u<=2?innov[u-1]:(copy[u-1]?prev2:innov[u-1]);auto o=turnover(s,target,0,tapes[u-1]);s=o.post;d=histnext(d,u,target,o.rejections,s);body+="T_u"+std::to_string(u)+"="+hx(target,8)+"\nretries_u"+std::to_string(u)+"="+std::to_string(o.rejections)+"\nS_u"+std::to_string(u)+"="+hex(statebytes(s))+"\nD_u"+std::to_string(u)+"="+hex(d)+"\n";prev2=prev1;prev1=target;}
 }
 else if(kind=="NUMVEC"){
  u32 n=u32(fi_dec(in.field("blocks"),42000));range(n>=1);auto constant=fi_nums(in.field("constant"));std::array<i64,6>s{};for(unsigned x=0;x<6;++x)s[x]=constant[x]*n;auto over=in.field("override");if(over!="NONE"){auto items=split(over,';');i64 last=-1;for(auto&item:items){auto pair=split(item,':');syntax(pair.size()==2);u32 b=u32(fi_dec(pair[0],n-1));range(i64(b)>last);last=b;auto v=fi_nums(pair[1]);for(unsigned x=0;x<6;++x)s[x]+=v[x]-constant[x];}}in.done();body=inferencebody(s,n,infer(s,n));
 }
 else if(kind=="CLASSIFIER"){
  auto f=split(in.field("iv"),',');range(f.size()==12);std::array<Interval,6>v;std::array<Label,6>l{};for(unsigned x=0;x<6;++x){try{v[x]={fraction(f[2*x]),fraction(f[2*x+1])};}catch(...){throw InputError("INPUT_SYNTAX");}range(v[x].lo<=v[x].hi);l[x]=classify(v[x],x);}in.done();for(unsigned x=0;x<6;++x)body+="LABEL "+endpoints()[x]+" "+labelname(l[x])+"\n";if(std::find(l.begin(),l.end(),FALL)!=l.end())body+="SUMMARY S0_INVALID\n";else body+=derived(v,l);
 }else throw InputError("INPUT_SYNTAX");
 return "BRC2-FIXOUT-V1\nfixture_id="+id+"\nstatus=OK\n"+body+"END\n";
 }catch(const InputError&e){return "BRC2-FIXOUT-V1\nfixture_id="+id+"\nstatus=ERROR "+e.what()+"\nEND\n";}catch(const DrawError&e){return "BRC2-FIXOUT-V1\nfixture_id="+id+"\nstatus=ERROR "+e.what()+"\nEND\n";}
}
}
