#include "fixin.hpp"
int main(int argc,char**argv){using namespace brc;try{auto m=cli(argc,argv,{"--in","--out"});auto in=readtext(m.at("--in"),u64(1)<<24);fs::path out=m.at("--out");require(!out.empty(),"out");out=fs::absolute(out);require(fs::exists(out.parent_path())&&!fs::exists(out),"out");atomictext(out,fixout(in),0400);return 0;}catch(...){std::cerr<<"usage/environment error\n";return 2;}}
