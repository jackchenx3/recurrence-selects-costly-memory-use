#include "dataset.hpp"
int main(int argc,char**argv){using namespace brc;Tier t;fs::path out;u32 n=0;
 try{auto m=cli(argc,argv,{"--tier","--out","--threads"});t=tier(m.at("--tier"));out=m.at("--out");require(!out.empty(),"output");n=u32(decimal(m.at("--threads"),32));require(n>=1,"threads");if(fs::exists(out))require(fs::is_directory(fs::symlink_status(out))&&fs::is_empty(out),"output not empty");else require(!fs::is_symlink(fs::symlink_status(out)),"output symlink");}catch(...){std::cerr<<"usage/environment error\n";return 2;}
 try{produce(t,out,n,executableid());std::cout<<"PASS\n";return 0;}catch(...){std::cerr<<"FAIL\n";return 1;}
}
