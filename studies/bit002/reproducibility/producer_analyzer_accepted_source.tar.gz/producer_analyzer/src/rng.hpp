#pragma once
#include "base.hpp"
namespace brc {
enum Purpose {INITIAL,TIME,INNOV,COPY,FRESH,SCOUT,LOCAL,DONOR,SURVIVAL,MUTATION,FOCAL};
inline const std::array<std::string,11>& purposes(){static const std::array<std::string,11> p={"INITIAL_GENOTYPE","CHECKPOINT_TIME","TARGET_INNOVATION","TARGET_COPY","FRESH_MASK","SCOUT_MASK","LOCAL_BIT","DONOR_KEY","SURVIVAL_UNIFORM","POLICY_MUTATION","FOCAL_PARENT"};return p;}
inline bool coordinate(const Tier&t,unsigned p,u32 b,u32 u,u32 e,u32 s){
 if(b>=t.n||p>=11)return false;
 if(p==INITIAL)return u==0&&e<32&&s==0;
 if(p==TIME)return u==0&&e==0&&s==0;
 if(u<1||u>256)return false;
 if(p==FOCAL){
  if(e>=32||s!=0)return false;
  auto d=sha(std::string(STUDY)+"|"+t.name+"|"+purposes()[TIME]);mm::PhiloxKey key{u32(get(d.data(),4)),u32(get(d.data()+4,4))};
  return u==checkpoint(t,mm::philox4x32_10({{b,0,0,0}},key)[0]);
 }
 switch(p){case INNOV:case COPY:return e==0&&s==0;case FRESH:case SCOUT:case MUTATION:return e<32&&s==0;case LOCAL:return e<32&&s<32;case DONOR:return e<96&&s==0;case SURVIVAL:return e<32&&s<256;default:return false;}
}
struct Tape {
 std::array<u32,32> fresh{},scout{},local{};
 std::array<u64,96> donor{};
 std::array<u64,32> focal{};
 u32 flip=0;
 std::function<u64(u32,u32)> survival;
};
struct Rng {
 Tier t;u32 b;std::array<mm::PhiloxKey,11> keys{};
 Rng(Tier t_,u32 b_):t(t_),b(b_){require(b<t.n,"block range");for(unsigned p=0;p<11;++p){auto d=sha(std::string(STUDY)+"|"+t.name+"|"+purposes()[p]);keys[p]={u32(get(d.data(),4)),u32(get(d.data()+4,4))};}}
 mm::PhiloxOutput words(unsigned p,u32 u,u32 e=0,u32 s=0)const{require(coordinate(t,p,b,u,e,s),"coordinate range");return mm::philox4x32_10({{b,u,e,s}},keys[p]);}
 u32 word(unsigned p,u32 u,u32 e=0,u32 s=0)const{return words(p,u,e,s)[0];}
 u64 wide(unsigned p,u32 u,u32 e=0,u32 s=0)const{auto w=words(p,u,e,s);return u64(w[0])|(u64(w[1])<<32);}
 Tape tape(u32 u)const{
  Tape d;for(u32 i=0;i<32;++i){d.fresh[i]=word(FRESH,u,i);d.scout[i]=word(SCOUT,u,i);for(u32 bit=0;bit<32;++bit)if((word(LOCAL,u,i,bit)&31)==0)d.local[i]|=u32(1)<<bit;
   for(u32 f=0;f<3;++f)d.donor[3*i+f]=wide(DONOR,u,3*i+f);
   if((word(MUTATION,u,i)&31)==0)d.flip|=u32(1)<<i;
   // Focal addresses exist only at the checkpoint; fetched by focal_keys().
  }
  d.survival=[self=*this,u](u32 draw,u32 r){return self.wide(SURVIVAL,u,draw,r);};return d;
 }
 void focal_keys(Tape& d,u32 u)const{for(u32 i=0;i<32;++i)d.focal[i]=wide(FOCAL,u,i);}
};
}
