#pragma once
#include "io.hpp"
#include "operator.hpp"
namespace brc {
using Record=std::array<u8,2088>;
struct Block {Record record{};std::vector<Digest>trace;};
inline void recordhash(Record&r){auto d=sha(r.data(),2056);std::copy(d.begin(),d.end(),r.begin()+2056);}
inline State prestate(const Record&r){State s;s.policy=u32(get(r.data()+52,4));s.valid=u32(get(r.data()+56,4));for(u32 i=0;i<32;++i){s.x[i]=u32(get(r.data()+104+4*i,4));s.cache[i]=u32(get(r.data()+232+4*i,4));}return s;}
inline std::array<Bytes,6> recordarms(const Record&r){std::array<Bytes,6>a;for(u32 i=0;i<6;++i)a[i]=Bytes(r.begin()+360+280*i,r.begin()+640+280*i);return a;}
inline std::array<i64,6> recordnums(const Record&r){return{{signed_field(r.data()+2040,1),signed_field(r.data()+2041,1),signed_field(r.data()+2042,2),signed_field(r.data()+2044,2),signed_field(r.data()+2046,1),signed_field(r.data()+2047,1)}};}
inline void storecheckpoint(Record&r,const Checkpoint&c){put(r.data()+36,c.eligible,4);r[40]=u8(c.e);r[41]=u8(c.e>0);r[42]=c.focal;put(r.data()+44,c.key,8);for(u32 a=0;a<6;++a)std::copy(c.arms[a].begin(),c.arms[a].end(),r.begin()+360+280*a);put(r.data()+2040,u64(c.nums[0]),1);put(r.data()+2041,u64(c.nums[1]),1);put(r.data()+2042,u64(c.nums[2]),2);put(r.data()+2044,u64(c.nums[3]),2);put(r.data()+2046,u64(c.nums[4]),1);put(r.data()+2047,u64(c.nums[5]),1);}
inline Block block(const Tier&t,u32 b){Rng rng(t,b);u32 w=rng.word(TIME,0),u=checkpoint(t,w),rt=rng.word(COPY,u)&1,inn=rng.word(INNOV,u);auto h=history(rng,u,b<t.trace);auto d=rng.tape(u);rng.focal_keys(d,u);auto c=evaluate(h.s,h.prev2,inn,rt,d);Block o;auto&r=o.record;std::memcpy(r.data(),"BRC2",4);put(r.data()+4,2,2);put(r.data()+6,2088,2);put(r.data()+8,b,4);r[12]=u8(b&1);r[13]=u8(rt);put(r.data()+14,u,2);put(r.data()+16,w,4);put(r.data()+20,h.prev2,4);put(r.data()+24,h.prev1,4);put(r.data()+28,inn,4);put(r.data()+32,rt?h.prev2:inn,4);r[43]=u8(1-rt);put(r.data()+52,h.s.policy,4);put(r.data()+56,h.s.valid,4);put(r.data()+60,128*(u-1),4);put(r.data()+64,768,4);put(r.data()+68,h.retries,4);std::copy(h.digest.begin(),h.digest.end(),r.begin()+72);
 for(u32 i=0;i<32;++i){put(r.data()+104+4*i,h.s.x[i],4);put(r.data()+232+4*i,h.s.cache[i],4);}storecheckpoint(r,c);put(r.data()+2048,128*(u+5),4);recordhash(r);o.trace=std::move(h.chain);return o;}
struct FileEntry{std::string name;u64 size;std::string digest;};
inline std::string manifest(const Tier&t,const Digest&id,const std::vector<FileEntry>&f,u64 queries){
 std::string s="BRC2-MANIFEST-V2\nstudy="+std::string(STUDY)+"\nprotocol_sha256="+PROTOCOL+"\ntier="+t.name+"\nproducer_build_id="+hex(id)+"\nblocks="+std::to_string(t.n)+"\nchunk_blocks=1000\nchunks="+std::to_string(t.chunks())+"\nrecord_length=2088\n";
 for(auto&e:f)s+="file "+e.name+" "+std::to_string(e.size)+" "+e.digest+"\n";return s+"total_queries="+std::to_string(queries)+"\ncomplete=1\n";
}
inline void produce(const Tier&t,const fs::path&out,u32 threads,const Digest&id,bool reverse=false){
 require(threads>=1&&threads<=32,"threads");emptydir(out);std::vector<Block>blocks(t.n);std::atomic<u32>next{0};std::exception_ptr error;std::mutex mu;
 auto work=[&]{try{for(;;){u32 k=next.fetch_add(1);if(k>=t.n)break;u32 b=reverse?t.n-1-k:k;blocks[b]=block(t,b);}}catch(...){std::lock_guard<std::mutex>lock(mu);if(!error)error=std::current_exception();next.store(t.n);}};
 std::vector<std::thread>pool;try{for(u32 i=0;i<threads;++i)pool.emplace_back(work);}catch(...){next.store(t.n);for(auto&th:pool)th.join();throw;}for(auto&th:pool)th.join();if(error)std::rethrow_exception(error);
 std::vector<FileEntry>files;u64 written=0,queries=0;auto commit=[&](const std::string&name,const Bytes&b){require(written+b.size()+8192<(u64(1)<<30),"directory budget");atomicfile(out/name,b);written+=b.size();files.push_back({name,b.size(),hex(sha(b))});};
 for(u32 k=0;k<t.chunks();++k){u32 first=1000*k,n=std::min(u32(1000),t.n-first);Bytes c(64,0);std::memcpy(c.data(),"BRC2CHNK",8);put(c.data()+8,2,2);put(c.data()+10,k,2);put(c.data()+12,first,4);put(c.data()+16,n,4);put(c.data()+20,2088,4);put(c.data()+24,t.code,4);std::copy(id.begin(),id.end(),c.begin()+32);
  for(u32 b=first;b<first+n;++b){auto&r=blocks[b].record;c.insert(c.end(),r.begin(),r.end());queries+=get(r.data()+2048,4);}commit(chunkname(k),c);}
 Bytes tr(32,0);std::memcpy(tr.data(),"BRC2TRCE",8);put(tr.data()+8,2,2);put(tr.data()+10,t.trace,2);put(tr.data()+12,t.code,4);
 for(u32 b=0;b<t.trace;++b){u32 u=u32(get(blocks[b].record.data()+14,2));require(blocks[b].trace.size()==u,"trace count");append(tr,b,4);append(tr,u,2);append(tr,u,2);for(auto&d:blocks[b].trace)append(tr,d);}commit("trace_audit_blocks.bin",tr);
 auto m=manifest(t,id,files,queries);require(m.size()<8192,"manifest budget");atomictext(out/"MANIFEST.txt",m);atomictext(out/"MANIFEST.sha256",hex(sha(m))+"  MANIFEST.txt\n");
}
struct Data {Tier t;Digest id{};std::string manifest_digest="NONE";u64 queries=0;std::vector<Record>records;std::vector<std::vector<Digest>>trace;};
// A loads and validates the complete DC inventory and chunk/trace structure.
inline Data load(const Tier&t,const fs::path&root){
 Data d;d.t=t;std::string m=readtext(root/"MANIFEST.txt",8191);d.manifest_digest=hex(sha(m));auto ls=lines(m);require(ls.size()==12+t.chunks(),"manifest line count"); // 9 header, k+1 files, 2 footer
 require(ls[0]=="BRC2-MANIFEST-V2"&&ls[1]=="study="+std::string(STUDY)&&ls[2]=="protocol_sha256="+std::string(PROTOCOL)&&ls[3]=="tier="+t.name,"manifest identity");
 require(ls[4].substr(0,18)=="producer_build_id="&&ishex(ls[4].substr(18),64),"build ID");auto id=unhex(ls[4].substr(18));std::copy(id.begin(),id.end(),d.id.begin());
 require(ls[5]=="blocks="+std::to_string(t.n)&&ls[6]=="chunk_blocks=1000"&&ls[7]=="chunks="+std::to_string(t.chunks())&&ls[8]=="record_length=2088","manifest counts");
 require(ls[ls.size()-1]=="complete=1"&&ls[ls.size()-2].substr(0,14)=="total_queries=","manifest complete");d.queries=decimal(ls[ls.size()-2].substr(14),1403136000);
 require(readtext(root/"MANIFEST.sha256",128)==d.manifest_digest+"  MANIFEST.txt\n","manifest hash");std::set<std::string>expected={"MANIFEST.txt","MANIFEST.sha256"};std::vector<Bytes>raw;
 for(u32 k=0;k<=t.chunks();++k){std::string name=k<t.chunks()?chunkname(k):"trace_audit_blocks.bin";expected.insert(name);auto f=split(ls[9+k],' ');require(f.size()==4&&f[0]=="file"&&f[1]==name&&ishex(f[3],64),"manifest file syntax");u64 n=decimal(f[2],u64(1)<<30);auto b=readfile(root/name);require(b.size()==n&&hex(sha(b))==f[3],"file integrity");raw.push_back(std::move(b));}
 std::set<std::string>actual;require(fs::is_directory(fs::symlink_status(root)),"data directory");for(auto&e:fs::directory_iterator(root)){require(fs::is_regular_file(e.symlink_status()),"inventory regular files");actual.insert(e.path().filename().string());}require(actual==expected,"inventory exact");d.records.resize(t.n);
 for(u32 k=0;k<t.chunks();++k){auto&b=raw[k];u32 first=k*1000,n=std::min(u32(1000),t.n-first);require(b.size()==64+2088*n,"chunk size");const u8*p=b.data();require(std::memcmp(p,"BRC2CHNK",8)==0&&get(p+8,2)==2&&get(p+10,2)==k&&get(p+12,4)==first&&get(p+16,4)==n&&get(p+20,4)==2088&&get(p+24,4)==t.code&&get(p+28,4)==0&&std::equal(d.id.begin(),d.id.end(),p+32),"chunk header");
  for(u32 j=0;j<n;++j){std::copy(p+64+2088*j,p+64+2088*(j+1),d.records[first+j].begin());require(get(d.records[first+j].data()+8,4)==first+j,"record IDs");}}
 auto&tr=raw.back();require(tr.size()>=32&&std::memcmp(tr.data(),"BRC2TRCE",8)==0&&get(tr.data()+8,2)==2&&get(tr.data()+10,2)==t.trace&&get(tr.data()+12,4)==t.code&&std::all_of(tr.begin()+16,tr.begin()+32,[](u8 c){return c==0;}),"trace header");d.trace.resize(t.trace);std::size_t off=32;
 for(u32 b=0;b<t.trace;++b){require(off+8<=tr.size(),"trace truncation");u32 u=u32(get(d.records[b].data()+14,2));require(u>=193&&u<=256&&get(tr.data()+off,4)==b&&get(tr.data()+off+4,2)==u&&get(tr.data()+off+6,2)==u,"trace entry");off+=8;require(off+32*u<=tr.size(),"trace size");for(u32 j=0;j<u;++j){Digest v;std::copy(tr.begin()+off,tr.begin()+off+32,v.begin());d.trace[b].push_back(v);off+=32;}}
 require(off==tr.size(),"trace exact size");return d;
}
}
