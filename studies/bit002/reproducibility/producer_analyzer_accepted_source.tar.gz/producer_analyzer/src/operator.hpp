#pragma once
#include "rng.hpp"
namespace brc {
// Adapted from accepted mm/model.hpp and p3/bit_adapter.cpp: BIT only.
struct State {std::array<u32,32>x{},cache{};u32 policy=0,valid=0;};
inline Bytes statebytes(const State& s){Bytes b;for(auto x:s.x)append(b,x,4);for(auto x:s.cache)append(b,x,4);append(b,s.policy,4);append(b,s.valid,4);return b;}
struct DrawError:Error{using Error::Error;};
struct Pick {u32 retry;u64 z;};
inline Pick lemire(u64 w,const std::function<u64(u32)>& source){
 require(w>=1&&w<=(u64(1)<<39),"weight sum");u64 threshold=(u64(0)-w)%w;
 for(u32 r=0;r<256;++r){u64 x=source(r);__uint128_t m=__uint128_t(x)*w;if(u64(m)>=threshold)return{r,u64(m>>64)};}
 throw DrawError("RETRY_CAP");
}
struct Turn {
 State post;std::array<u32,128>g{},m{};std::array<u8,32>selected{},retries{},donor{};
 u32 queries=0,rejections=0,sum_mismatch=0;
};
inline Turn turnover(const State&s,u32 target,u32 q,const Tape&d){
 require((s.valid&~s.policy)==0,"invalid policy/cache");require((q&~(s.policy&s.valid))==0,"switched slot ineligible");Turn o;
 for(u32 i=0;i<32;++i){u32 bit=u32(1)<<i;o.g[i]=s.x[i];o.g[32+i]=((s.policy&s.valid&bit)&&!(q&bit))?s.cache[i]:(s.x[i]^d.fresh[i]);o.g[64+i]=s.x[i]^d.scout[i];}
 for(u32 j=0;j<96;++j){o.m[j]=pop(o.g[j]^target);++o.queries;}
 for(u32 i=0;i<32;++i){u32 best=0;for(u32 f=1;f<3;++f)if(o.m[32*f+i]<o.m[32*best+i]||(o.m[32*f+i]==o.m[32*best+i]&&d.donor[3*i+f]<d.donor[3*i+best]))best=f;
  o.donor[i]=u8(best);o.g[96+i]=o.g[32*best+i]^d.local[i];o.m[96+i]=pop(o.g[96+i]^target);++o.queries;}
 require(o.queries==128,"query invariant");std::array<u64,128>w{};std::array<bool,128>taken{};
 for(u32 j=0;j<128;++j){w[j]=u64(1)<<(32-o.m[j]);o.sum_mismatch+=o.m[j];}
 for(u32 draw=0;draw<32;++draw){u64 total=0;for(u32 j=0;j<128;++j)if(!taken[j]){require(total<=(u64(1)<<39)-w[j],"sum overflow");total+=w[j];}
  Pick p=lemire(total,[&](u32 r){return d.survival(draw,r);});u64 acc=0;u32 j=0;for(;j<128;++j)if(!taken[j]){acc+=w[j];if(acc>p.z)break;}require(j<128,"PL scan");taken[j]=true;o.selected[draw]=u8(j);o.retries[draw]=u8(p.retry);o.rejections+=p.retry;
  u32 parent=j%32,bit=u32(1)<<draw;bool post=((s.policy>>parent)^(d.flip>>draw))&1;o.post.x[draw]=o.g[j];if(post){o.post.policy|=bit;o.post.valid|=bit;o.post.cache[draw]=s.x[parent];}
 }
 return o;
}
struct Checkpoint {u32 eligible=0,e=0;u8 focal=255;u64 key=~u64(0);std::array<Bytes,6>arms;std::array<i64,6>nums{};};
inline std::array<i64,6> numerators(const std::array<Bytes,6>& a){return{{i64(a[0][12])-a[1][12],i64(a[3][12])-a[4][12],i64(get(a[0].data()+14,2))-i64(get(a[1].data()+14,2)),i64(get(a[3].data()+14,2))-i64(get(a[4].data()+14,2)),i64(a[0][13])-a[2][13],i64(a[3][13])-a[5][13]}};}
inline Checkpoint evaluate(const State&s,u32 rec,u32 inn,u32 rt,const Tape& d){
 require(rt<=1,"r_t");Checkpoint c;c.eligible=s.policy&s.valid;c.e=pop(c.eligible);
 for(u32 i=0;i<32;++i)if(c.eligible&(u32(1)<<i))if(c.focal==255||d.focal[i]<c.key){c.focal=u8(i);c.key=d.focal[i];}
 // Six separate full turnovers; no identity shortcut or deduplication.
 for(u32 a=0;a<6;++a){u32 q=a%3==0?0:(a%3==1?c.eligible:(c.focal==255?0:u32(1)<<c.focal));auto o=turnover(s,a<3?rec:inn,q,d);Bytes b(280,0);b[0]=u8(a);b[1]=u8(a/3);b[2]=u8(a%3);b[3]=u8(a==(rt?0:3));put(b.data()+4,q,4);put(b.data()+8,o.queries,2);put(b.data()+10,o.rejections,2);put(b.data()+16,o.post.policy,4);put(b.data()+20,o.sum_mismatch,4);u32 accuracy=0;
  for(u32 k=0;k<32;++k){u32 j=o.selected[k],parent=j%32;auto p=b.data()+24+8*k;p[0]=u8(j);p[1]=u8(o.m[j]);p[2]=u8((o.post.policy>>k)&1);p[3]=o.retries[k];put(p+4,o.g[j],4);b[12]+=u8((c.eligible>>parent)&1);b[13]+=u8(parent==c.focal);accuracy+=32-o.m[j];}
  put(b.data()+14,accuracy,2);c.arms[a]=std::move(b);
 }
 c.nums=numerators(c.arms);return c;
}
inline Digest hist0(u32 b,const State&s){Bytes x;literal(x,"BRC2-HIST-V2");append(x,b,4);auto z=statebytes(s);x.insert(x.end(),z.begin(),z.end());require(x.size()==280,"initial chain message size");return sha(x);}
inline Digest histnext(const Digest&d,u32 u,u32 target,u32 retries,const State&s){Bytes x;append(x,d);append(x,u,2);append(x,target,4);append(x,retries,4);auto z=statebytes(s);x.insert(x.end(),z.begin(),z.end());require(x.size()==306,"chain message size");return sha(x);}
struct History {State s;u32 prev2=0,prev1=0,retries=0;Digest digest{};std::vector<Digest>chain;};
inline History history(const Rng&r,u32 t,bool trace){
 require(t>=193&&t<=256,"checkpoint range");History h;h.s.policy=(r.b&1)?~u32(0):0;for(u32 i=0;i<32;++i)h.s.x[i]=r.word(INITIAL,0,i);h.digest=hist0(r.b,h.s);if(trace)h.chain.push_back(h.digest);
 for(u32 u=1;u<t;++u){u32 inn=r.word(INNOV,u),copy=r.word(COPY,u)&1,target=u<=2?inn:(copy?h.prev2:inn);auto o=turnover(h.s,target,0,r.tape(u));h.s=o.post;h.retries+=o.rejections;h.prev2=h.prev1;h.prev1=target;h.digest=histnext(h.digest,u,target,o.rejections,h.s);if(trace)h.chain.push_back(h.digest);}
 return h;
}
}
