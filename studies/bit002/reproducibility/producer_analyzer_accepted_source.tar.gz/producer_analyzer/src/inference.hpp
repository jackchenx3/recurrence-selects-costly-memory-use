#pragma once
#include "base.hpp"
#include <boost/multiprecision/cpp_int.hpp>
namespace brc {
using Big=boost::multiprecision::cpp_int;
inline Big absbig(Big v){return v<0?-v:v;}
inline Big gcd(Big a,Big b){a=absbig(a);b=absbig(b);while(b!=0){Big r=a%b;a=b;b=r;}return a;}
struct Rat {
 Big p,q;
 Rat(Big n=0,Big d=1):p(n),q(d){require(q!=0,"zero denominator");if(q<0){p=-p;q=-q;}Big g=brc::gcd(p,q);p/=g;q/=g;}
 std::string str()const{return p.convert_to<std::string>()+"/"+q.convert_to<std::string>();}
};
inline Rat operator+(const Rat&a,const Rat&b){return{a.p*b.q+b.p*a.q,a.q*b.q};}
inline Rat operator-(const Rat&a,const Rat&b){return{a.p*b.q-b.p*a.q,a.q*b.q};}
inline Rat operator/(const Rat&a,unsigned b){return{a.p,a.q*b};}
inline bool operator<(const Rat&a,const Rat&b){return a.p*b.q<b.p*a.q;}
inline bool operator>(const Rat&a,const Rat&b){return b<a;}
inline bool operator<=(const Rat&a,const Rat&b){return !(b<a);}
inline bool operator==(const Rat&a,const Rat&b){return a.p==b.p&&a.q==b.q;}
inline Big bigint(const std::string&s){require(!s.empty(),"integer syntax");std::size_t i=s[0]=='-'?1:0;require(i<s.size()&&(s.substr(i)=="0"||(s[i]>='1'&&s[i]<='9'))&&s!="-0","integer syntax");Big v=0;for(;i<s.size();++i){require(s[i]>='0'&&s[i]<='9',"integer syntax");v=v*10+(s[i]-'0');}return s[0]=='-'?-v:v;}
inline Rat fraction(const std::string&s){auto v=split(s,'/');require(v.size()==2,"fraction syntax");Big p=bigint(v[0]),q=bigint(v[1]);require(q>0,"fraction denominator");Rat r(p,q);require(r.str()==s,"fraction canonical");return r;}
inline Rat halfwidth(unsigned x){return x<4?Rat(Big("15608294208001326"),Big("1000000000000000000")):Rat(Big("2378115509733596"),Big("1000000000000000000"));}
inline Rat delta(unsigned x){return Rat(1,x<4?64:256);}
inline Rat margin(unsigned x){return Rat(1,x<4?32:128);}
inline const std::array<std::string,6>& endpoints(){static const std::array<std::string,6>x={"L_rec","L_inn","P_rec","P_inn","F_rec","F_inn"};return x;}
enum Label{MP,MN,NG,POS,NEG,FALL};
inline std::string labelname(Label x){static const char*n[]={"MATERIAL_POSITIVE","MATERIAL_NEGATIVE","NEGLIGIBLE_WITHIN_MARGIN","POSITIVE_MAGNITUDE_UNRESOLVED","NEGATIVE_MAGNITUDE_UNRESOLVED","FALLTHROUGH"};return n[x];}
struct Interval {Rat lo,hi;};
inline Label classify(const Interval&v,unsigned x){Rat d=delta(x),e=margin(x);if(v.lo>d)return MP;if(v.hi<Rat()-d)return MN;if(v.lo>Rat()-e&&v.hi<e)return NG;if(v.lo>Rat())return POS;if(v.hi<Rat())return NEG;return FALL;}
inline bool material(Label l){return l==MP||l==MN;}
inline bool signonly(Label l){return l==POS||l==NEG;}
inline bool positive(Label l){return l==MP||l==POS;}
inline std::string pattern(Label a,Label b){
 if((a==MP&&b==MN)||(a==MN&&b==MP))return "OFFSETTING_MATERIAL";
 if(a==MP&&b==MP)return "CONCORDANT_MATERIAL_POSITIVE";
 if(a==MN&&b==MN)return "CONCORDANT_MATERIAL_NEGATIVE";
 if(material(a)&&b==NG)return std::string("RECURRENT_ONLY_MATERIAL_")+(a==MP?"POSITIVE":"NEGATIVE");
 if(a==NG&&material(b))return std::string("INNOVATION_ONLY_MATERIAL_")+(b==MP?"POSITIVE":"NEGATIVE");
 if((material(a)&&signonly(b))||(signonly(a)&&material(b)))return std::string("ONE_MATERIAL_OTHER_SIGN_ONLY_")+(positive(a)==positive(b)?"SAME":"OPPOSING");
 if(a==NG&&b==NG)return "BOTH_NEGLIGIBLE";
 if((a==POS&&b==NEG)||(a==NEG&&b==POS))return "OPPOSING_SIGNS_NONMATERIAL";
 require(a!=FALL&&b!=FALL,"classification fallthrough");return "NONMATERIAL_OTHER";
}
inline std::string joined(const std::vector<std::string>&v){std::string s;for(auto&x:v){if(!s.empty())s+=",";s+=x;}return s;}
struct Inference {std::array<Rat,6>means;std::array<Interval,6>iv;std::array<Label,6>labels{};};
inline Inference infer(const std::array<i64,6>&s,u32 n){require(n>=1&&n<=42000,"cohort size");Inference r;for(unsigned x=0;x<6;++x){i64 bound=x<2?32:(x<4?1024:4);require(s[x]>=-bound*n&&s[x]<=bound*n,"sum bounds");r.means[x]=Rat(s[x],(x==2||x==3?1024:32)*n);Rat range=x<4?Rat(1):Rat(1,8),h=halfwidth(x);r.iv[x]={std::max(Rat()-range,r.means[x]-h),std::min(range,r.means[x]+h)};r.labels[x]=classify(r.iv[x],x);require(r.labels[x]!=FALL,"L fallthrough");require(r.iv[x].lo<=r.iv[x].hi&&r.iv[x].hi-r.iv[x].lo<=h+h,"L interval width");}return r;}
inline std::string summary(const std::array<Label,6>&l){
 for(auto v:l)if(v==FALL)return "SUMMARY S0_INVALID\n";
 const std::array<std::string,3>q={"L","P","F"};std::vector<std::string>names;for(unsigned j=0;j<3;++j)if(pattern(l[2*j],l[2*j+1])=="OFFSETTING_MATERIAL")names.push_back(q[j]);if(!names.empty())return "SUMMARY S1_MATERIAL_TARGET_OFFSETTING quantities="+joined(names)+"\n";
 for(unsigned j=0;j<6;++j)if(l[j]==MN)names.push_back(endpoints()[j]);if(!names.empty())return "SUMMARY S2_MATERIAL_ADVERSE_PRESENT endpoints="+joined(names)+"\n";
 for(unsigned j=0;j<6;++j)if(l[j]==MP)names.push_back(endpoints()[j]);if(!names.empty())return "SUMMARY S3_MATERIAL_POSITIVE_ONLY endpoints="+joined(names)+"\n";
 if(std::all_of(l.begin(),l.end(),[](Label v){return v==NG;}))return "SUMMARY S4_ALL_NEGLIGIBLE_WITHIN_MARGIN\n";
 for(unsigned j=0;j<6;++j)if(signonly(l[j]))names.push_back(endpoints()[j]);require(!names.empty(),"summary completeness");return "SUMMARY S5_NONMATERIAL_SIGN_RESOLVED endpoints="+joined(names)+"\n";
}
inline std::string derived(const std::array<Interval,6>&v,const std::array<Label,6>&l){std::string s;const std::array<std::string,3>q={"L","P","F"};for(unsigned j=0;j<3;++j){auto&a=v[2*j];auto&b=v[2*j+1];Rat dlo=a.lo-b.hi,dhi=a.hi-b.lo;s+="DERIVED "+q[j]+" avg_lo="+((a.lo+b.lo)/2).str()+" avg_hi="+((a.hi+b.hi)/2).str()+" diff_lo="+dlo.str()+" diff_hi="+dhi.str()+" resolved_difference="+std::string(dlo>Rat()||dhi<Rat()?"1":"0")+"\nPATTERN "+q[j]+" "+pattern(l[2*j],l[2*j+1])+"\n";}return s+summary(l);}
inline std::string inferencebody(const std::array<i64,6>&s,u32 n,const Inference&r){std::string o;for(unsigned x=0;x<6;++x)o+="ENDPOINT "+endpoints()[x]+" sum="+std::to_string(s[x])+" den="+std::to_string((x==2||x==3?1024:32)*n)+" mean="+r.means[x].str()+" lo="+r.iv[x].lo.str()+" hi="+r.iv[x].hi.str()+" label="+labelname(r.labels[x])+"\n";return o+derived(r.iv,r.labels);}
struct Stats{std::array<i64,6>sums{};std::array<std::array<i64,6>,2>starts{};std::array<std::array<u32,33>,2>ehist{};std::array<u32,2>h{},r1{};std::array<u64,2>factual{};};
inline std::string validresults(const Tier&t,const std::string&mh,const Stats&s){auto r=infer(s.sums,t.n);std::string o="BRC2-RESULTS-V3\nstatus=VALID\ntier="+t.name+"\nmanifest_sha256="+mh+"\nblocks="+std::to_string(t.n)+"\n"+inferencebody(s.sums,t.n,r);
 o+="DESC H_count ALL_F="+std::to_string(s.h[0])+" ALL_M="+std::to_string(s.h[1])+"\n";
 for(unsigned k=0;k<2;++k){o+=std::string("DESC E_hist ")+(k?"ALL_M=":"ALL_F=");for(unsigned e=0;e<=32;++e){if(e)o+=",";o+=std::to_string(s.ehist[k][e]);}o+="\n";}
 o+="DESC R1_count ALL_F="+std::to_string(s.r1[0])+" ALL_M="+std::to_string(s.r1[1])+"\n";
 for(unsigned k=0;k<2;++k){o+=std::string("DESC startsum ")+(k?"ALL_M":"ALL_F");for(unsigned x=0;x<6;++x)o+=" "+endpoints()[x]+"="+std::to_string(s.starts[k][x]);o+="\n";}
 o+="DESC factual_A_sum ALL_F="+std::to_string(s.factual[0])+" ALL_M="+std::to_string(s.factual[1])+"\nEND\n";require(std::count(o.begin(),o.end(),'\n')==26,"L render lines");return o;
}
inline std::string invalidresults(const Tier&t,const std::string&mh,const std::string&failed){return "BRC2-RESULTS-V3\nstatus=INVALID\ntier="+t.name+"\nmanifest_sha256="+mh+"\nfailed_checks="+failed+"\nSUMMARY S0_INVALID\nEND\n";}
// Reporting support; never called by the sealed analyzer or benchmark.
inline std::string interpretation(const Inference&r){std::string s;const char*quantity[]={"eligible-lineage share","eligible-lineage share","survivor-population accuracy","survivor-population accuracy","focal-family lineage share","focal-family lineage share"};for(unsigned x=0;x<6;++x){Label l=r.labels[x];require(l!=FALL,"invalid interpretation");s+=std::string("At ")+(x%2?"innovation":"recurrent")+" checkpoint targets, "+(x<4?"all eligible carriers' cached rather than paired-fresh retrieval":"the focal eligible parent's cached rather than paired-fresh retrieval")+" for one turnover ";if(material(l))s+=std::string(l==MP?"increased ":"decreased ")+quantity[x]+" by more than "+delta(x).str()+" relative to paired-fresh retrieval";else if(l==NG)s+="changed "+std::string(quantity[x])+" by less than "+margin(x).str()+" in magnitude. This bounds, and does not establish absence of, an effect";else s+=std::string(l==POS?"increased ":"decreased ")+quantity[x]+", with magnitude relative to "+delta(x).str()+" and "+margin(x).str()+" unresolved";s+=" (simultaneous 95% interval ["+r.iv[x].lo.str()+", "+r.iv[x].hi.str()+"] for CACHE minus FRESH).\n";}
 for(unsigned j=0;j<3;++j)if(pattern(r.labels[2*j],r.labels[2*j+1])=="OFFSETTING_MATERIAL")s+="The average interval for "+std::string(j==0?"L":j==1?"P":"F")+" is an average of opposing effects and does not establish a small or absent effect.\n";
 s+="L is capped by min(1, e/8, (32-e)/8); negligible L must be reported with the e distribution. L and F are separate interventions. Target differences are heterogeneity at identical states, and do not estimate an effect of recurrence. F follows the hashed focal-selection rule and remains unconditional. Full history provenance is replayed only for the fixed 64 blocks (16 in fixture tier); conditional replay elsewhere establishes the stored-state operator relation only.\n";return s;}
}
