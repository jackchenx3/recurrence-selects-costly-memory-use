This is the BIT-only BRC2 v0.4 producer-author source package. The accepted protocol is copied unchanged and bound by SHA-256 `71ccc1d065fa4868c30f96588ec34312bdc435e1047214c60b1f5643846c7daa`.

**Source construction only. Nothing here has been compiled, imported, executed, simulated, or fixture-tested.** No empirical results or implementation FIXOUT files exist. Non-author G1F and G1 acceptance must precede any build or fixture invocation.

The package contains:

- `src/`: producer, complete BIT/RNG/serialization core, analyzer checks A–L, exact rational inference, FIXIN reader and FIXOUT renderer, fixture harness entry point, and two declared vendor primitives.
- `public/`: protocol, REV1, official KAT and license, static FIXIN bundle and hash index, 33 new keys, exact legacy key strings/source hashes, and standard-tool metadata. It contains inputs only.
- `private_expectations/`: author hand reasoning, expected constructed-fixture values, and F1–F10/corruption harness support. This directory is prohibited auditor-author input.
- `docs/`: static walkthrough, coverage map, later-gate commands, dependency requirements, and consulted/copied source identities.
- `SOURCE_CONSTRUCTION_REPORT.txt`, `SOURCE_INVENTORY.tsv`, `SHA256SUMS`: source-only disposition and exact review snapshot.

Read `SOURCE_CONSTRUCTION_REPORT.txt` and `docs/STATIC_WALKTHROUGH.txt` for review. Read `docs/LATER_GATES.txt` for commands that are deliberately unexecuted. Boost.Multiprecision headers are a declared requirement; their availability is not asserted. GCC 8.5/Linux compatibility is a source target, not an observed build result.

Only protocol/REV1/official RNG material may go to the independent auditor author before G1F. After G1F, release the sanitized FIXIN inputs. Independent key computation must be frozen before comparing it with the producer table. Producer/analyzer source, this README, private expectations, source-review commentary, and construction transcripts are not auditor-author inputs. Raw fixture/benchmark data and producer FIXOUT are released only after the independent auditor source freeze at G4a. There is no auditor implementation or auditor retry in this package.
